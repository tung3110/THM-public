
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "ip_flk.h"
#include "cJSON.h"
#include "device_config.h"
#include "ip_dbg.h"
#include "board_hw.h"
#include "app_aes.h"
#include "utils.h"
#include <limits.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define SYS_CONFIG_RAW_DATA "amz.txt"
#define SYS_CONFIG_BINARY_DATA "amz.bin"

static const char *KEY_DELAY_ON = "DL_ON";
static const char *KEY_DELAY_OFF_1 = "DL_OFF_1";
static const char *DL_OFF_2 = "delay_off_2";
static const char *KEY_DTMF_1 = "PC817_ON";
static const char *KEY_DTMF_2 = "PC817_OFF";
static const char *KEY_DTMF_RETRIES = "dPC817_COUNT";
static const char *KEY_DTMF_ACTIVE = "PC817_ACTIVE";
static const char *KEY_WIFI_NAME = "WFN";
static const char *KEY_WIFI_PASS = "WFP";
static const char *KEY_WIFI_EN = "WFE";
static char *APP_FLASH_KEY_DEVICE_NAME = "dev_name";
#define APP_FLASH_KEY_GROUP "gri_ttn"
#define APP_FLASH_KEY_PROTOCOL_PRIORITY "pro_pri"


static device_config_t m_device_config = 
{
    .imei = "000000000000000",
    .log_to_file = 0,
    .protocol_type = 2
};
static const char *DEFAULT_MQTT_INFO = "{"
  "\"broker\": \"emqx.thongtinnguon.com\","
  "\"port\": 2023,"
  "\"username\": \"ttn.emqx\","
  "\"password\": \"emqx938slk0\","
  "\"imei\": \"000\","
  "\"sim_imei\": \"000\","
  "\"stream_url\": \"http://device-stream.truyenthanhso.com:3001/\","
  "\"volume_0\": 70,"
  "\"reset_counter\": 0,"
  "\"working_mode\": 1,"
  "\"dev_name\":\"THM\","
  "\"gri_ttn\": ["
    "{"
    "  \"id\": \"1\","
    "  \"pri\": 0"
    "},"
    "{"
    "  \"id\": \"2\","
    "  \"pri\": 0"
    "},"
    "{"
    "  \"id\": \"3\","
    "  \"pri\": 0"
    "}"
  "]"
"}";

static char m_sys_mac_str[24];
static uint8_t m_mac_addr[13];
static char m_binary_path[256], m_application_dir[256];
static uint8_t m_raw_sys_configuration[1024];
static uint8_t m_raw_aes_buf[1024];
static uint8_t m_out_aes_buf[2048];

void sys_save_key_and_string_value_to_json(char *key, char *value)
{
    if (!key || !value)
    {
        return;
    }
    
    cJSON *key_str;
    char *json_str = NULL;
    cJSON *root = NULL;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGE("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_str = cJSON_GetObjectItem(root, key);
    if (!key_str)
    {
        A_LOGE("JSON key %s invalid\r\n", key);
        cJSON_AddStringToObject(root, key, value);
        goto save_config;
    }
    cJSON_SetValuestring(key_str, value);


save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

static void get_dir(char *binary_path, char *dir)
{
    int len = strlen(m_binary_path);
    if (len > 0)
    {
        strcpy(dir, binary_path);
        dir += len - 1;
        while (dir && dir > binary_path && *dir != '/')
        {
            dir--;
            if (*dir == '/')
            {
                *dir = 0;
                return;
            }
        }
    }
}

char *ip_flk_get_binary_path()
{
    if (strlen(m_binary_path) == 0)
    {
        // Get binary path
        readlink("/proc/self/exe", m_binary_path, sizeof(m_binary_path));
    }
    return m_binary_path;
}

void ip_flk_start()
{
    ip_flk_get_binary_path();
    get_dir(m_binary_path, m_application_dir);
    char mac_raw[48];
    ip_flk_get_mac_addr(mac_raw, m_sys_mac_str);
#if TEST_LINUX_HARDWARE
    sprintf(m_device_config.imei, "PI_%s", "1234");
#endif
}

static uint8_t *gen_aes_key(uint8_t *mac)
{
    return "43hR1Y88n9!2?@.Q";
}


int ip_flk_get_device_type()
{
    return IP_FLK_DEVICE_TYPE_DECODER;
}

void ip_flk_temporary_set_log_to_tty(int new_log)
{
    m_device_config.log_to_tty = new_log;
}

void ip_flk_load_configuration()
{
    int file_size = 0;
    char raw_cfg[1024];
    
    sprintf(raw_cfg, "%s/%s", m_application_dir, SYS_CONFIG_RAW_DATA);

    FILE *f = fopen(raw_cfg, "r");
    uint8_t *key;
    cJSON *root = NULL;
    cJSON *key_reset_counter, *key_reset_reason, *key_broker, *key_username, *key_password, *key_port;
    cJSON *key_last_streaming_master, *key_vol, *key_mode;
    cJSON *key_gsm_imei, *key_sim_imei, *key_stream_url;
    cJSON *key_debug_level, *key_master, *key_log_tty;
    
 
    m_device_config.debug_level = DBG_LVL_INFO;
    if (!f)
    {
        printf("Unable to open cfg file\r\n");
        goto open_encrypted_file;
    }

    key = gen_aes_key(m_mac_addr);
    if (fgets((char*)m_raw_sys_configuration, sizeof(m_raw_sys_configuration)-1, f))
    {
        fclose(f);
        f = NULL;
        // printf("Sys cfg %s\r\n", m_raw_sys_configuration);
        int aes_buffer_length = AES_ECB_encrypt((uint8_t *)m_raw_sys_configuration, 
                                                (uint8_t *)key, 
                                                (char*)m_raw_aes_buf, 
                                                strlen((char *)m_raw_sys_configuration));
        memset(m_raw_sys_configuration, 0, sizeof(m_raw_sys_configuration));

        // Save to encrypted file
        sprintf(raw_cfg, "%s/%s", m_application_dir, SYS_CONFIG_BINARY_DATA);
        f = fopen(raw_cfg,"w");
        if (!f)
        {
            printf("Create encrypted configuration file err\r\n");
            goto exit;
        }
        
        file_size = fwrite(m_raw_aes_buf, 1, aes_buffer_length, f);
        if (file_size != aes_buffer_length)
        {
            printf("Write binary data to enc file failed %d != %d\r\n", 
                        file_size, 
                        aes_buffer_length);
            goto exit;
        }

        // printf("Write to file %s success\r\n", raw_cfg);
        fclose(f);
        f = NULL;
        sprintf(raw_cfg, "%s/%s", m_application_dir, SYS_CONFIG_RAW_DATA);
        remove(raw_cfg);
        goto open_encrypted_file;
    }
    else
    {
        fclose(f);
        f = NULL;
        goto exit;
    }

open_encrypted_file:
    sprintf(raw_cfg, "%s/%s", m_application_dir, SYS_CONFIG_BINARY_DATA);
    f = fopen(raw_cfg, "r");
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    if (!f)
    {
        printf("Open encrypted file failed\r\n");
        sprintf(m_raw_sys_configuration, "%s", DEFAULT_MQTT_INFO);
        goto parse_json;
        goto exit;
    }
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    // Get file size
    file_size = fseek(f, 0L, SEEK_END);
    file_size = ftell(f);
    fseek(f, 0L, SEEK_SET);
    
    // Read raw data
    fread(m_raw_aes_buf, file_size, 1, f);

    if (file_size > 0)
    {
        // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
        memset(m_raw_sys_configuration, 0, sizeof(m_raw_sys_configuration));
        key = gen_aes_key(m_mac_addr);
        AES_ECB_decrypt((uint8_t*)m_raw_aes_buf, 
                        key, 
                        (uint8_t*)m_raw_sys_configuration, 
                        file_size);
    }
    
    // printf("DBG cfg: %s\r\n", m_raw_sys_configuration);
    board_hw_sleep(1000);
parse_json:
    // Load configuration
    root = cJSON_Parse(m_raw_sys_configuration);
    // A_LOGV("CFG  %s", m_raw_sys_configuration);
    char *q = m_raw_sys_configuration;
    char *p = NULL;
    while (q)
    {
        q = strstr(q, "}");
        if (q)
        {
            p = q;
            q++;
        }
        else if (p)
        {
            *(p+1) = 0;
            break;
        }
    }
    
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    if (!root)
    {
        printf("Not a JSON, select default\r\n");
        sprintf(m_raw_sys_configuration, "%s", DEFAULT_MQTT_INFO);
        printf("%s\r\n", m_raw_sys_configuration);
        root = cJSON_Parse(m_raw_sys_configuration);
    }
    
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    // Broker
    key_broker = cJSON_GetObjectItem(root, "broker");
    if (!key_broker)
    {
        A_LOGW("JSON key broker invalid\r\n");
        goto exit;
    }
    sprintf(m_device_config.mqtt.url, "%s", key_broker->valuestring);
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);

    // Username
    key_username = cJSON_GetObjectItem(root, "username");
    if (!key_username)
    {
        A_LOGW("JSON key username invalid\r\n");
        goto exit;
    }
    sprintf(m_device_config.mqtt.username, "%s", key_username->valuestring);

    // Password
    key_password = cJSON_GetObjectItem(root, "password");
    if (!key_password)
    {
        A_LOGW("JSON key password invalid\r\n");
        goto exit;
    }
    snprintf(m_device_config.mqtt.password, 64, "%s", key_password->valuestring);

    // Port
    key_port = cJSON_GetObjectItem(root, "port");
    if (!key_port)
    {
        A_LOGW("JSON key port invalid\r\n");
        goto exit;
    }
    m_device_config.mqtt.port = key_port->valueint;

    key_port = cJSON_GetObjectItem(root, APP_FLASH_KEY_DEVICE_NAME);
    if (key_port && cJSON_IsString(key_port))
    {
        sprintf(m_device_config.m_device_name, "%s", key_port->valuestring);
    }

    // Vol
    for (int index = 0; index < 3; index++)
    {
        char volume_ind[32];
        sprintf(volume_ind, "volume_%d", index);

        key_vol = cJSON_GetObjectItem(root, volume_ind);
        if (key_vol)
        {
            m_device_config.volume[index] = key_vol->valueint;
        }
        else
        {
            m_device_config.volume[index] = 70;
        }
    }

    // Last streaming master
    key_last_streaming_master = cJSON_GetObjectItem(root, "last_streaming_master");
    if (key_last_streaming_master)
    {
        sprintf(m_device_config.last_stream_master, 
                "%s", 
                key_last_streaming_master->valuestring);
    }

    // IMEI & SIM
    key_gsm_imei = cJSON_GetObjectItem(root, "imei");
    if (key_gsm_imei)
    {
        sprintf(m_device_config.imei, "%s", key_gsm_imei->valuestring);
    }

    key_sim_imei = cJSON_GetObjectItem(root, "sim_imei");
    if (key_sim_imei)
    {
        sprintf(m_device_config.ccid, "%s", key_sim_imei->valuestring);
    }


    key_gsm_imei = cJSON_GetObjectItem(root, KEY_WIFI_NAME);
    if (key_gsm_imei)
    {
        snprintf(m_device_config.wifi_name, 64, "%s", key_gsm_imei->valuestring);
    }

    key_gsm_imei = cJSON_GetObjectItem(root, KEY_WIFI_PASS);
    if (key_gsm_imei)
    {
        snprintf(m_device_config.wifi_password, 64, "%s", key_gsm_imei->valuestring);
    }

    // Stream URL
    key_stream_url = cJSON_GetObjectItem(root, "stream_url");
    if (key_stream_url)
    {
        sprintf(m_device_config.stream_url, "%s", key_stream_url->valuestring);
    }

    // Mode
    key_mode = cJSON_GetObjectItem(root, "working_mode");
    if (key_mode)
    {
        m_device_config.mode = key_mode->valueint;
    }

    // Reset counter & reset reason
    key_reset_counter = cJSON_GetObjectItem(root, "reset_counter");
    if (key_reset_counter)
    {
        m_device_config.reset_counter = key_reset_counter->valueint;
    }

    key_reset_reason = cJSON_GetObjectItem(root, "reset_reason");
    if (key_reset_reason)
    {
        m_device_config.reset_reason = key_reset_reason->valueint;
    }

    // Load debug level
    key_debug_level = cJSON_GetObjectItem(root, "debug_level");
    if (key_debug_level)
    {
        m_device_config.debug_level = key_debug_level->valueint;
    }

    // Log to file
    key_log_tty = cJSON_GetObjectItem(root, "tty");
    if (key_log_tty)
    {
        m_device_config.log_to_tty = key_log_tty->valueint;
    }

    key_log_tty = cJSON_GetObjectItem(root, "log_level");
    if (key_log_tty)
    {
        m_device_config.log_level = key_log_tty->valueint;
    }
    else
    {
        m_device_config.log_level = DBG_LVL_ERROR;
    }

    key_log_tty = cJSON_GetObjectItem(root, "log_file");
    if (key_log_tty)
    {
        m_device_config.log_to_file = key_log_tty->valueint;
    }
    else
    {
        m_device_config.log_to_file = 0;
    }
    // m_device_config.log_to_file = 1;

    printf("Level at start %d\r\n", m_device_config.log_level);
    ip_dbg_set_level(m_device_config.log_level);

    // Load relay delay on, off1, off2
    key_log_tty = cJSON_GetObjectItem(root, KEY_DELAY_ON);
    if (key_log_tty)
    {
        m_device_config.relay_delay_on = key_log_tty->valueint;
    } 
    else
    {
        m_device_config.relay_delay_on = 30;
    }

    key_log_tty = cJSON_GetObjectItem(root, KEY_DELAY_OFF_1);
    if (key_log_tty)
    {
        m_device_config.relay_delay_off_1 = key_log_tty->valueint;
    }
    else
    {
        m_device_config.relay_delay_off_1 = 60;
    } 

    key_log_tty = cJSON_GetObjectItem(root, DL_OFF_2);
    if (key_log_tty)
    {
        m_device_config.relay_delay_off_2 = key_log_tty->valueint;
    } 
    else
    {
        m_device_config.relay_delay_off_2 = 60;
    }

    key_log_tty = cJSON_GetObjectItem(root, KEY_DTMF_1);
    if (key_log_tty)
    {
        m_device_config.dtmf_on = key_log_tty->valueint;
        if (m_device_config.dtmf_on == 0)
        {
            m_device_config.dtmf_on = 6;
        }
    } 
    else
    {
        m_device_config.dtmf_on = 10;
    }
    

    key_log_tty = cJSON_GetObjectItem(root, KEY_DTMF_2);
    if (key_log_tty)
    {
        m_device_config.dtmf_off = key_log_tty->valueint;
        if (m_device_config.dtmf_off == 0)
        {
            m_device_config.dtmf_off = 6;
        }
    } 
    else
    {
        m_device_config.dtmf_off = 10;
    }

    key_log_tty = cJSON_GetObjectItem(root, KEY_DTMF_RETRIES);
    if (key_log_tty)
    {
        m_device_config.dtmf_count = key_log_tty->valueint;
    } 
    else
    {
        m_device_config.dtmf_count = 2;
    }

    key_log_tty = cJSON_GetObjectItem(root, KEY_DTMF_ACTIVE);
    if (key_log_tty)
    {
        m_device_config.active_level = key_log_tty->valueint;
    } 
    else
    {
        m_device_config.active_level = 0;
    }

  // Group info
    key_log_tty = cJSON_GetObjectItem(root, APP_FLASH_KEY_GROUP);
    if (key_log_tty)
    {
        cJSON *tmp;
        int gr_count = 0;
        cJSON_ArrayForEach(tmp, key_log_tty)
        {
            cJSON * key_id = cJSON_GetObjectItem(tmp, "id");
            cJSON * key_pri = cJSON_GetObjectItem(tmp, "pri");
            if (key_id && key_id->valuestring)
            {
                sprintf(m_device_config.m_group_info[gr_count].group_id, "%s", key_id->valuestring);
            }
            else
            {
                m_device_config.m_group_info[gr_count].group_id[0] = '\0';
            }
            if (key_pri)
            {
                m_device_config.m_group_info[gr_count].priority = key_pri->valueint;
            }
            else
            {
                m_device_config.m_group_info[gr_count].priority = 0;
            }
            gr_count++;
        }
    }
    else
    {
        for (int i = 0; i < APP_FLASH_MAX_GROUP_SUPPORT; i++)
        {
            m_device_config.m_group_info[i].group_id[0] = '\0';
        }
    }

exit:
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    if (root)
        cJSON_Delete(root);
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    if (f)
        fclose(f);
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
}

char *ip_flk_get_mac_string()
{
    return m_sys_mac_str;
}

bool ip_flk_get_mac_addr(char *mac_raw, char *mac_str)
{
    bool retval = false;
    FILE *f = fopen("/sys/class/net/end0/address", "r");
    if (!f)
    {
        f = fopen("/sys/class/net/wlan0/address", "r");
        if (!f)
        {
            A_LOGW("Unable to open /sys/class/net/wlan0/address\r\n");
            goto exit;
        }
    }
    char tmp[32];

    if (fgets(tmp, 23, f))
    {
        // Remove \r\n

        char *crlf = strstr(tmp, "\r");
        if (crlf)
        {
            *crlf = 0;
        }
        crlf = strstr(tmp, "\n");
        if (crlf)
        {
            *crlf = 0;
        }


        int j = 0;
        for (int i = 0; i < strlen(tmp); i++)
        {
            if (tmp[i] != ':')      // remove ":"
            {
                mac_str[j++] = tmp[i];
            }
        }

        char *pos = mac_str;
        for (size_t count = 0; count < 6; count++) 
        {
            sscanf(pos, "%2hhx", &mac_raw[count]);
            pos += 2;
        }
        retval = true;
    }

    fclose(f);
exit:
    return retval;
}


void ip_flk_save_current_config(void)
{
    FILE *f;
    int aes_buffer_length;
    uint8_t *key;
    int size_written;
    A_LOGI("New cfg \r\n%s\r\n", m_raw_sys_configuration);
    // char *q = strstr(m_raw_sys_configuration, "}");
    // if (q)
    // {
    //     *(q+1) = 0;
    // }
    // static char tmp_buf[1024];
    // sprintf(tmp_buf, "%s", m_raw_sys_configuration);
    memset(m_raw_aes_buf, 0, sizeof(m_raw_aes_buf));
    // Save to encrypted file
    char raw_cfg[1024];
    sprintf(raw_cfg, "%s/%s", m_application_dir, SYS_CONFIG_BINARY_DATA);
    f = fopen(raw_cfg, "w");
    A_LOGI("Open %s\r\n", raw_cfg);
    // mqtt_publish_message("DBG", "Open %s\r\n", raw_cfg);
    if (!f)
    {
        A_LOGW("Create encrypted configuration file err\r\n");
        perror("");
        goto exit;
    }
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    key = gen_aes_key(m_mac_addr);
    aes_buffer_length = AES_ECB_encrypt((uint8_t *)m_raw_sys_configuration, 
                                        (uint8_t *)key, 
                                        (char*)m_raw_aes_buf, 
                                        strlen((char *)m_raw_sys_configuration));

    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    size_written = fwrite(m_raw_aes_buf, 1, aes_buffer_length, f);
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    memset(m_raw_aes_buf, 0, sizeof(m_raw_aes_buf));
    if (size_written != aes_buffer_length)
    {
        A_LOGW("Write binary data to enc file failed %d != %d\r\n", 
                    size_written, aes_buffer_length);
        goto exit;
    }

    char *q = m_raw_sys_configuration;
    char *p = NULL;
    while (q)
    {
        q = strstr(q, "}");
        if (q)
        {
            p = q;
            q++;
        }
        else if (p)
        {
            *(p+1) = 0;
            break;
        }
    }
    
    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    // mqtt_publish_message("DBG", "Write to file OK %s, payload %s\r\n", raw_cfg, m_raw_sys_configuration);
    A_LOGV("Write to file success %s\r\n", m_raw_sys_configuration);
exit:
    if (f)
    {
        // printf("Close file\r\n");
        fflush(f);
        fclose(f);
    }
    utils_run_shell_cmd(NULL, 0, true, "sync");
}



void ip_flk_save_gsm_imei(char *imei)
{
    if (!imei)
    {
        return;
    }
    cJSON *key_gsm_imei;
    char *json_str = NULL;
    cJSON *root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_gsm_imei = cJSON_GetObjectItem(root, "imei");
    if (!key_gsm_imei)
    {
        A_LOGW("JSON key imei invalid\r\n");
        goto exit;
    }
    cJSON_SetValuestring(key_gsm_imei, imei);
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_stream_url()
{
    cJSON *key_stream_url;
    char *json_str = NULL;
    cJSON *root = cJSON_Parse(m_raw_sys_configuration);

    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }
    
    // Stream URL
    key_stream_url = cJSON_GetObjectItem(root, "stream_url");
    if (!key_stream_url)
    {
        A_LOGW("JSON key stream_url invalid\r\n");
        goto exit;
    }
    cJSON_SetValuestring(key_stream_url, m_device_config.stream_url);
    
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_mqtt_info(broker_info_t *info)
{
    cJSON *key_broker, *key_port, *key_username, *key_password;
    char *json_str = NULL;
    cJSON *root = NULL;
    
    if (info)
    {
        root = cJSON_Parse(m_raw_sys_configuration);
    }
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON %s\r\n", 
                    __FUNCTION__,
                    m_raw_sys_configuration);
        goto exit;
    }
    
    // Broker
    key_broker = cJSON_GetObjectItem(root, "broker");
    if (!key_broker)
    {
        A_LOGW("JSON key broker invalid\r\n");
        goto exit;
    }
    
    sprintf(m_device_config.mqtt.url, "%s", info->url);
    sprintf(m_device_config.mqtt.username, "%s", info->username);
    sprintf(m_device_config.mqtt.password, "%s", info->password);
    m_device_config.mqtt.port = info->port;

    cJSON_SetValuestring(key_broker, m_device_config.mqtt.url);

    // Port
    key_port = cJSON_GetObjectItem(root, "port");
    if (!key_port)
    {
        A_LOGW("JSON key port invalid\r\n");
        goto exit;
    }
    cJSON_SetIntValue(key_port, m_device_config.mqtt.port);

    // Username
    key_username = cJSON_GetObjectItem(root, "username");
    if (!key_username)
    {
        A_LOGW("JSON key username invalid\r\n");
        goto exit;
    }
    cJSON_SetValuestring(key_username, m_device_config.mqtt.username);

    // Password
    key_password = cJSON_GetObjectItem(root, "password");
    if (!key_username)
    {
        A_LOGW("JSON key password invalid\r\n");
        goto exit;
    }
    cJSON_SetValuestring(key_password, m_device_config.mqtt.password);

    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

int ip_flk_get_dtmf_on()
{
    return m_device_config.dtmf_on;
}

void ip_flk_save_dtmf_on(int delay)
{
    cJSON *key_dtmf1;
    char *json_str = NULL;
    cJSON *root = NULL;
    
    m_device_config.dtmf_on = delay;
    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_dtmf1 = cJSON_GetObjectItem(root, KEY_DTMF_1);
    if (!key_dtmf1)
    {
        A_LOGW("JSON key DTMF1 invalid\r\n");
        cJSON_AddNumberToObject(root, KEY_DTMF_1, delay);
        goto save_config;
    }
    cJSON_SetIntValue(key_dtmf1, delay);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

int ip_flk_get_dtmf_off()
{
    return m_device_config.dtmf_off;
}

void ip_flk_save_dtmf_off(int delay)
{
    cJSON *key_dtmf2;
    char *json_str = NULL;
    cJSON *root = NULL;
    
    m_device_config.dtmf_off = delay;
    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_dtmf2 = cJSON_GetObjectItem(root, KEY_DTMF_2);
    if (!key_dtmf2)
    {
        A_LOGW("JSON key DTMF2 invalid\r\n");
        cJSON_AddNumberToObject(root, KEY_DTMF_2, delay);
        goto save_config;
    }
    cJSON_SetIntValue(key_dtmf2, delay);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}



int ip_flk_get_dtmf_count()
{
    return m_device_config.dtmf_count;
}

void ip_flk_save_dtmf_count(int count)
{
    cJSON *key_dtmf_count;
    char *json_str = NULL;
    cJSON *root = NULL;
    
    m_device_config.dtmf_count = count;
    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_dtmf_count = cJSON_GetObjectItem(root, KEY_DTMF_RETRIES);
    if (!key_dtmf_count)
    {
        A_LOGW("JSON key DTMF count invalid\r\n");
        cJSON_AddNumberToObject(root, KEY_DTMF_RETRIES, count);
        goto save_config;
    }
    cJSON_SetIntValue(key_dtmf_count, count);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

int ip_flk_get_dtmf_active_level()
{
    return m_device_config.active_level ? 1 : 0;
}

void ip_flk_save_dtmf_active(int active)
{
    cJSON *key_dtmf_active;
    char *json_str = NULL;
    cJSON *root = NULL;
    active = active ? 1 : 0;

    m_device_config.active_level = active;
    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_dtmf_active = cJSON_GetObjectItem(root, KEY_DTMF_ACTIVE);
    if (!key_dtmf_active)
    {
        A_LOGW("JSON key DTMF active invalid\r\n");
        cJSON_AddNumberToObject(root, KEY_DTMF_RETRIES, active);
        goto save_config;
    }
    cJSON_SetIntValue(key_dtmf_active, active);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_tty_flag(int tty_enable)
{
    cJSON *key_tty;
    char *json_str = NULL;
    cJSON *root = NULL;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_tty = cJSON_GetObjectItem(root, "tty");
    if (!key_tty)
    {
        A_LOGW("JSON key tty invalid\r\n");
        cJSON_AddNumberToObject(root, "tty", tty_enable);
        goto save_config;
    }
    cJSON_SetIntValue(key_tty, tty_enable);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_log_level(int level)
{
    cJSON *key_level;
    char *json_str = NULL;
    cJSON *root = NULL;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_level = cJSON_GetObjectItem(root, "log_level");
    if (!key_level)
    {
        A_LOGW("JSON key log_level invalid\r\n");
        cJSON_AddNumberToObject(root, "log_level", level);
        m_device_config.log_level = level;
        goto save_config;
    }
    A_LOGW("Set new log level %d\r\n", level);
    cJSON_SetIntValue(key_level, level);
    m_device_config.log_level = level;
    ip_dbg_set_level(level);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_log_to_file_flag(int enable)
{
    cJSON *key_log_to_file;
    char *json_str = NULL;
    cJSON *root = NULL;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_log_to_file = cJSON_GetObjectItem(root, "log_file");
    if (!key_log_to_file)
    {
        A_LOGW("JSON key log_level invalid\r\n");
        cJSON_AddNumberToObject(root, "log_file", enable);
        goto save_config;
    }
    cJSON_SetIntValue(key_log_to_file, enable);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_working_mode(int mode)
{
    cJSON *key_mode;
    char *json_str = NULL;
    cJSON *root = NULL;
    
    m_device_config.mode = mode;
    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_mode = cJSON_GetObjectItem(root, "working_mode");
    if (!key_mode)
    {
        A_LOGW("JSON key mode invalid\r\n");
        cJSON_AddNumberToObject(root, "working_mode", mode);
        goto save_config;
    }
    cJSON_SetIntValue(key_mode, mode);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

int ip_flk_get_relay_delay_on()
{
    return m_device_config.relay_delay_on;
}

void ip_flk_save_relay_DL_ON(int value)
{
    cJSON *key_DL_ON;
    char *json_str = NULL;
    cJSON *root = NULL;

    m_device_config.relay_delay_on = value;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_DL_ON = cJSON_GetObjectItem(root, KEY_DELAY_ON);
    if (!key_DL_ON)
    {
        A_LOGW("JSON key %s invalid\r\n", KEY_DELAY_ON);
        cJSON_AddNumberToObject(root, KEY_DELAY_ON, value);
        goto save_config;
    }
    cJSON_AddNumberToObject(root, KEY_DELAY_ON, value);


save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

int ip_flk_get_relay_delay_off1()
{
    return m_device_config.relay_delay_off_1;
}

int ip_flk_get_relay_delay_off2()
{
    return m_device_config.relay_delay_off_2;
}

void ip_flk_save_relay_delay_off_1(int value)
{
    cJSON *key_delay_off_1;
    char *json_str = NULL;
    cJSON *root = NULL;
    m_device_config.relay_delay_off_1 = value;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_delay_off_1 = cJSON_GetObjectItem(root, KEY_DELAY_OFF_1);
    if (!key_delay_off_1)
    {
        A_LOGW("JSON key %s invalid\r\n", KEY_DELAY_OFF_1);
        cJSON_AddNumberToObject(root, KEY_DELAY_OFF_1, value);
        goto save_config;
    }
    cJSON_AddNumberToObject(root, KEY_DELAY_OFF_1, value);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_relay_delay_off_2(int value)
{
    cJSON *key_delay_off_2;
    char *json_str = NULL;
    cJSON *root = NULL;

    m_device_config.relay_delay_off_2 = value;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_delay_off_2 = cJSON_GetObjectItem(root, DL_OFF_2);
    if (!key_delay_off_2)
    {
        A_LOGW("JSON key %s invalid\r\n", DL_OFF_2);
        cJSON_AddNumberToObject(root, DL_OFF_2, value);
        goto save_config;
    }
    cJSON_AddNumberToObject(root, DL_OFF_2, value);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

void ip_flk_save_reset_reason(int reason)
{
    cJSON *key_reset_json;
    char *json_str = NULL;
    cJSON *root = NULL;
    
    m_device_config.reset_reason = reason;
    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_reset_json = cJSON_GetObjectItem(root, "reset_reason");
    if (!key_reset_json)
    {
        A_LOGW("JSON key reset reason invalid\r\n");
        cJSON_AddNumberToObject(root, "reset_reason", reason);
        goto save_config;
    }
    cJSON_SetIntValue(key_reset_json, reason);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

int ip_flk_get_reset_counter()
{
    return m_device_config.reset_counter;
}

int ip_flk_get_volume(int index)
{
    if (index >= 3)
    {
        return 0;
    }
    return m_device_config.volume[index];
}

char *ip_flk_get_last_streaming_master()
{
    return m_device_config.last_stream_master;
}

void ip_flk_set_last_streaming_master()
{
    return;
//     cJSON *key_last_master;
//     char *json_str = NULL;
//     cJSON *root = cJSON_Parse(m_raw_sys_configuration);

//     if (!root)
//     {
//         A_LOGW("[%s] : Not a JSON, \r\n%s\r\n", 
//                     __FUNCTION__, m_raw_sys_configuration);
//         goto exit;
//     }
    
//     // Broker
//     key_last_master = cJSON_GetObjectItem(root, "last_streaming_master");
//     if (!key_last_master)
//     {
//         A_LOGW("JSON key last_streaming_master invalid\r\n");
//         cJSON_AddStringToObject(root, "last_streaming_master", m_device_config.last_stream_master);
//     }
//     else
//     {
//         cJSON_SetValuestring(key_last_master, m_device_config.last_stream_master);
//     }

//     json_str = cJSON_Print(root);
//     strcpy(m_raw_sys_configuration, json_str);
//     // mqtt_publish_message("DBG", "%s", m_raw_sys_configuration);
//     ip_flk_save_current_config();
// exit:
//     if (json_str)
//         cJSON_free(json_str);

//     if (root)
//         cJSON_Delete(root);
}

int ip_flk_get_working_mode()
{
    return m_device_config.mode;
}

void ip_flk_save_reset_counter(int counter)
{
    A_LOGI("\r\n%s\r\n", m_raw_sys_configuration);
//     cJSON *key_reset_counter;
//     char *json_str = NULL;
//     cJSON *root = cJSON_Parse(m_raw_sys_configuration);
//     if (!root)
//     {
//         A_LOGW("[%s] : Not a JSON %s, payload %s\r\n", __FUNCTION__, m_raw_sys_configuration);
//         goto exit;
//     }

//     key_reset_counter = cJSON_GetObjectItem(root, "reset_counter");
//     if (!key_reset_counter)
//     {
//         // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
//         A_LOGW("JSON key reset counter invalid\r\n");
//         cJSON_AddNumberToObject(root, "reset_counter", counter);
//         goto save_config;
//     }
//     // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
//     cJSON_SetIntValue(key_reset_counter, counter);

// save_config:
//     // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
//     json_str = cJSON_Print(root);
//     strcpy(m_raw_sys_configuration, json_str);
//     ip_flk_save_current_config();
// exit:
//     if (json_str)
//         cJSON_free(json_str);

//     if (root)
//         cJSON_Delete(root);
}

void ip_flk_save_sim_ccid(char *ccid)
{
    if (!ccid)
    {
        return;
    }
    cJSON *key_ccid;
    char *json_str = NULL;
    cJSON *root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_ccid = cJSON_GetObjectItem(root, "sim_imei");
    if (!key_ccid)
    {
        A_LOGW("JSON key sim_imei invalid\r\n");
        goto exit;
    }
    cJSON_SetValuestring(key_ccid, ccid);
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}


char *ip_flk_mqtt_get_username()
{
    return m_device_config.mqtt.username;
}

char *ip_flk_mqtt_get_pwd()
{
    return m_device_config.mqtt.password;
}

static char m_url[256] = "";
char *ip_flk_mqtt_get_url(void)
{
    return m_device_config.mqtt.url;
}

int ip_flk_mqtt_get_port(void)
{
    return m_device_config.mqtt.port;
}


void ip_flk_set_sim_imsi(char *imsi)
{
    if (imsi && strcmp(m_device_config.imsi, imsi))
    {
        sprintf(m_device_config.imsi, "%s", imsi);
    }
}

void ip_flk_set_sim_ccid(char *ccid)
{
    if (ccid && strcmp(m_device_config.ccid, ccid))
    {
        sprintf(m_device_config.ccid, "%s", ccid);
    }
}

char *ip_flk_get_last_streaming_url()
{
    return m_device_config.stream_url;
}

bool ip_flk_is_mute()
{
    return m_device_config.mute == 1;
}

void ip_flk_mute(bool is_mute)
{
    if (m_device_config.mute == is_mute)
    {
        return;
    }
    // TODO
    m_device_config.mute = is_mute;
}

void ip_flk_set_volume(int index, int volume)
{
    if (m_device_config.volume[index] == volume)
    {
        return;
    }
    m_device_config.volume[index] = volume;
    cJSON *key_vol;
    char *json_str = NULL;
    cJSON *root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGW("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    char volume_ind[32];
    sprintf(volume_ind, "volume_%d", index);
    key_vol = cJSON_GetObjectItem(root, volume_ind);
    if (!key_vol)
    {
        A_LOGW("JSON key %s invalid, add number %d to object\r\n", volume_ind, volume);
        cJSON_AddNumberToObject(root, volume_ind, volume);
        goto save_config;
    }
    
    cJSON_SetIntValue(key_vol, volume);
save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

char *ip_flk_get_device_name()
{
    return ip_flk_get_mac_string();
}

void sys_save_group()
{
    cJSON *key_master, *tmp;
    char *json_str = NULL;
    cJSON *root = cJSON_Parse(m_raw_sys_configuration);
    int i = 0;
    if (!root)
    {
        A_LOGE("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    // groups
    key_master = cJSON_GetObjectItem(root, APP_FLASH_KEY_GROUP);
    if (!key_master)
    {
        A_LOGE("JSON key group invalid\r\n");
        cJSON *gr_array = cJSON_CreateArray();
        for (int i = 0; i < APP_FLASH_MAX_GROUP_SUPPORT; i++)
        {
            cJSON *new_group = cJSON_CreateObject();
            // Add "ID" and "priority" fields to the array item
            cJSON_AddStringToObject(new_group, "id", "");
            cJSON_AddNumberToObject(new_group, "pri", 1);

            // Add the object to the array
            cJSON_AddItemToArray(gr_array, new_group);
        }
        cJSON_AddItemToObject(root, APP_FLASH_KEY_GROUP, gr_array);
        json_str = cJSON_Print(root);
        strcpy(m_raw_sys_configuration, json_str);
        printf("New cfg %s\r\n", m_raw_sys_configuration);

        cJSON_free(json_str);
        json_str = NULL;

        root = cJSON_Parse(m_raw_sys_configuration);
        key_master = cJSON_GetObjectItem(root, APP_FLASH_KEY_GROUP);
    }


    cJSON_ArrayForEach(tmp, key_master)
    {
        cJSON *key_id = cJSON_GetObjectItem(tmp, "id");
        cJSON *key_pri = cJSON_GetObjectItem(tmp, "pri");
        if (!key_id)
        {
            A_LOGE("JSON key_id invalid\r\n");
            cJSON_AddStringToObject(tmp, "id", m_device_config.m_group_info[i].group_id);
        }
        else 
        {
            printf("Add new %s\r\n", m_device_config.m_group_info[i].group_id);
            cJSON_SetValuestring(key_id, m_device_config.m_group_info[i].group_id);
        }
        if (!key_pri)
        {
            A_LOGE("JSON key_pri invalid\r\n");
            cJSON_AddNumberToObject(tmp, "pri", m_device_config.m_group_info[i].priority);
        }
        else 
        {
            cJSON_SetIntValue(key_pri, m_device_config.m_group_info[i].priority);
        }
        i++;
    }

save_config:
    json_str = cJSON_Print(root);
    printf("New json2 : %s\r\n", json_str);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

int ip_flk_get_log_level()
{
    return m_device_config.log_level;
}

void app_flash_set_group_name(char *name, uint8_t priority)
{
    int first_free_index = -1;
    bool do_save_config = false;
    if (!name || strlen(name) < 3)
    {
        return;
    }

    for (int i = 0; i < APP_FLASH_MAX_GROUP_SUPPORT; i++)
    {
        if (strncmp(name, m_device_config.m_group_info[i].group_id, APP_FLASH_MAX_GROUP_NAME_LEN) == 0)
        {
            if (priority != m_device_config.m_group_info[i].priority)
            {
                m_device_config.m_group_info[i].priority = priority;
                first_free_index = -1;
                do_save_config = true;
                A_LOGI("[0] Save group %s\r\n", m_device_config.m_group_info[i].group_id);
                break;
            }
        }
        else if (first_free_index < 0 && strlen(m_device_config.m_group_info[i].group_id) < 3)
        {
            first_free_index = i;
        }
    }

    if (first_free_index >= 0)
    {
        do_save_config = true;
        m_device_config.m_group_info[first_free_index].priority = priority;
        strncpy(m_device_config.m_group_info[first_free_index].group_id, name, APP_FLASH_MAX_GROUP_NAME_LEN);
        A_LOGI("[1] Save group %s\r\n", m_device_config.m_group_info[first_free_index].group_id);
    }


    if (do_save_config)
    {
        sys_save_group();
    }
}

app_flash_group_info_t *app_flash_get_group_info(int index)
{
    if (index >= APP_FLASH_MAX_GROUP_SUPPORT)
    {
        return NULL;
    }
    if (strlen(m_device_config.m_group_info[index].group_id) < 3)
    {
        return NULL;
    }

    return &m_device_config.m_group_info[index];
}


int app_flash_find_group_priority(char *master)
{
    for (int i = 0; i < APP_FLASH_MAX_GROUP_SUPPORT; i++)
    {
        if (strncmp(master, m_device_config.m_group_info[i].group_id, APP_FLASH_MAX_GROUP_NAME_LEN) == 0)
        {
            return m_device_config.m_group_info[i].priority;
        }
    }
    return -1;
}

void app_flash_remove_group(char *id)
{
    uint8_t save = 0;
    for (int i = 0; i < APP_FLASH_MAX_GROUP_SUPPORT; i++)
    {
        if (strncmp(id, m_device_config.m_group_info[i].group_id, APP_FLASH_MAX_GROUP_NAME_LEN) == 0)
        {
            memset(m_device_config.m_group_info[i].group_id, 0, APP_FLASH_MAX_GROUP_NAME_LEN);
            m_device_config.m_group_info[i].priority = 0;
            A_LOGW("Removed group id %s\r\n", id);
            save++;
            // return;
        }
    }
    if (save)
    {
        sys_save_group();
    }
}


void app_flash_remove_all_group()
{
    memset(m_device_config.m_group_info, 0, sizeof(m_device_config.m_group_info));
    // sys_save_group();
}

int ip_flk_get_protocol_priority()
{
    return m_device_config.protocol_type;
}

void sys_save_protocol_priority(int priority)
{
    cJSON *key_priority;
    char *json_str = NULL;
    cJSON *root = NULL;

    root = cJSON_Parse(m_raw_sys_configuration);
    if (!root)
    {
        A_LOGE("[%s] : Not a JSON\r\n", __FUNCTION__);
        goto exit;
    }

    key_priority = cJSON_GetObjectItem(root, APP_FLASH_KEY_PROTOCOL_PRIORITY);
    if (!key_priority)
    {
        A_LOGE("JSON key %s invalid\r\n", APP_FLASH_KEY_PROTOCOL_PRIORITY);
        cJSON_AddNumberToObject(root, APP_FLASH_KEY_PROTOCOL_PRIORITY, priority);
        goto save_config;
    }
    cJSON_SetIntValue(key_priority, priority);

save_config:
    json_str = cJSON_Print(root);
    strcpy(m_raw_sys_configuration, json_str);
    ip_flk_save_current_config();
exit:
    if (json_str)
        cJSON_free(json_str);

    if (root)
        cJSON_Delete(root);
}

char *app_flash_get_human_device_name()
{
    return m_device_config.m_device_name;
}

/*
 * @brief   Function set device name
 */
void app_flash_set_human_device_name(char *name)
{
    if (name && strncmp(name, m_device_config.m_device_name, APP_FLASH_DEVICE_NAME_MAX_LENGTH))
    {
        strncpy(m_device_config.m_device_name, name, APP_FLASH_DEVICE_NAME_MAX_LENGTH);
        sys_save_key_and_string_value_to_json(APP_FLASH_KEY_DEVICE_NAME, m_device_config.m_device_name);
    }
}
