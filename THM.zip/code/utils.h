#ifndef UTILS_H
#define UTILS_H
#include <stdint.h>
#include <stdbool.h>

void utils_get_active_interface(char *interface);

uint32_t utils_sys_get_second(void);
char *utils_cpu_get_load_avg(void);
char *utils_get_free_ram();
int utils_run_shell_cmd(char *buffer, int buffer_size, bool wait_to_complete, const char *fmt, ...);
int utils_reboot(void);
uint32_t utils_get_number_from_string(uint16_t begin_addr, char* buffer);
int utils_is_domain_name(const char *name);
int utils_get_cpu_temperature();
char *utils_get_disk_usage();

#endif