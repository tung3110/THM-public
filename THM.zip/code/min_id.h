#ifndef MIN_ID_H
#define MIN_ID_H


#define MIN_ID_PING_MCU                         0x03
#define MIN_ID_PING                         0x00
#define MIN_ID_STREAM_REPORT                0x01
#define MIN_ID_START_STREAMMING             0x02
#define MIN_ID_STOP_STREAMING               0x03
#define MIN_ID_SET_GPIO 0x01
#define MIN_ID_MAC 70
#define MIN_ID_RESET                        0x06
#endif /* MIN_ID_H */
