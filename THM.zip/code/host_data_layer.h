#ifndef HOST_DATA_LAYER_H
#define HOST_DATA_LAYER_H

#include <stdint.h>

typedef enum
{
    HOST_POWER_STARTING,
    HOST_POWER_UP,
    HOST_POWER_PULSE_PWR_KEY,
    HOST_POWER_RUNNING,
    HOST_POWER_WAIT_FOR_VIN,
    HOST_POWER_DOWN,
    HOST_POWER_FLASH_MODE
} host_power_state_t;

typedef union
{
    struct
    {
        uint32_t dtmf1                              : 1;
        uint32_t dtmf2                              : 1;
        uint32_t led_vol                            : 4;
        uint32_t speaker_on_off                     : 1;
        uint32_t relay1                             : 1;
        uint32_t relay2                             : 1;
        uint32_t meeting_led                        : 1;
        uint32_t switch_in                          : 1;
        uint32_t switch_out                         : 1;
        uint32_t lte_led_r                          : 1;
        uint32_t lte_led_b                          : 1;
        uint32_t eth_led_r                          : 1;
        uint32_t eth_led_b                          : 1;
        uint32_t pa                                 : 1;
        uint32_t sw_mic                             : 1;
        uint32_t if_4g                              : 1;
        uint32_t if_wifi                            : 1;
        uint32_t if_eth                             : 1;
        uint32_t operation_mode                     : 3;
        uint32_t nextion_enable                     : 1;
        uint32_t sw_mic_in_from_mic_line_or_hp      : 1;        // config_mic
        uint32_t sw_line_out_in_from_mic_line_or_hp : 1;        // con hp mach ATTH 7 inch
        uint32_t sw_lineout_enable                  : 1;        // en_hph_out
        uint32_t sw_pa_out_from_mic_line_or_hp      : 1;        // config hp mach node PA
        uint32_t class_d                            : 1;
    } __attribute__((packed)) name;
    uint32_t value;
} __attribute__((packed)) host_data_layer_output_t;

typedef union
{
    struct
    {
        uint16_t btn_up         : 1;
        uint16_t btn_down         : 1;
        uint16_t btn_menu         : 1;
        uint16_t btn_ok         : 1;
        uint16_t input4         : 1;        // bit nay khong dung nhung de tuong thich nguoc voi ATTH -> van them vao
        uint16_t button_on_air  : 1;
        uint16_t reserve        : 10;
    } __attribute__((packed)) name;
    uint16_t value;
} __attribute__((packed)) host_data_layer_input_t;

typedef union
{
    struct
    {
        uint8_t d_vol_err         : 1;
        uint8_t class_d           : 4;
        uint8_t heartbeat_err     : 1;
        uint8_t reserve           : 2;
    } __attribute__((packed)) name;
    uint8_t value;
} __attribute__((packed)) host_data_layer_debug_flag_t;

typedef struct
{
    uint8_t screen_id;
    uint8_t temperature;
    uint16_t vi_sense;
    uint8_t headphone;
    host_data_layer_input_t input;
    host_data_layer_output_t output;
    uint8_t hardware_version[3];
    uint8_t firmware_version[3];
    uint8_t mic;        // dont care
    uint8_t line_in;    // dont care
    uint16_t vin_half;    // dont care
    host_data_layer_debug_flag_t error_flag;
} __attribute__((packed)) host_data_layer_ping_msg_t;

#endif // HOST_DATA_LAYER_H