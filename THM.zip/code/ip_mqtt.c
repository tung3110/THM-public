#include "ip_mqtt.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include "MQTTAsync.h"
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include "sys/un.h"
#include <min.h>
#include <stddef.h>
#include <stdarg.h>
#include "base64.h"
#if defined(_WRS_KERNEL)
#include <OsWrapper.h>
#endif
#include <signal.h>
#include "ip_dbg.h"
#include "app_aes.h"
#include "cJSON.h"
#include "app_serial.h"
#include "gsm.h"
#include "gsm_utilities.h"
#include "lwrb.h"
#include "app_md5.h"
#include "device_config.h"
#include "board_hw.h"
#include "ip_wdt.h"
#include "ring_buf.h"
#include "utils.h"
#include "ip_flk.h"
#include "stream_info.h"
#include "audio.h"
#include "ip_io.h"
#include "mqtt_msg_id.h"
#include "eth_manager.h"
#include "wifi_manager.h"
#include "assert.h"

#define QOS          1

#define MQTT_THREAD_CYCLE_MS 1000L
#define DEFAULT_MQTT_TIMEOUT_DO_RESET (1000000*MQTT_THREAD_CYCLE_MS)  // 1000s
#define MQTT_AUTO_SUB_INTERVAL (61000/MQTT_THREAD_CYCLE_MS)           // 61s
#define MQTT_AUTO_PUB_INTERVAL (60000/MQTT_THREAD_CYCLE_MS)           // 60s

#define AUTO_REPORT_LOAD_AVG (900000/MQTT_THREAD_CYCLE_MS)           // 900s



typedef struct
{
    uint8_t firmware_version;
    uint8_t hardware_version;
    uint16_t vin;
    uint16_t v5v;
    uint16_t vgsm;
    uint8_t output_control;     // PA|RL1|RL2
    uint16_t input_state;
} mcu_info_t;

typedef struct
{
    // @SerializedName("C")
    uint8_t audio_class;		//loại class mạch PA
    // @SerializedName("D")
    uint8_t detect_value;	//Giá trị tín hiệu detect
    // @SerializedName("E")
    uint8_t err_state;		//Trạng thái lỗi: 1 - lỗi, 0 - bình thường
} speaker_info_t;

//fmInfo: Thông tin trạng thái mạch FM
typedef struct  
{
    // // @SerializedName("F")
    uint32_t freq;	//Tần số thu hiện tại (x10 = Freq thực tế)
    // // @SerializedName("S")
    int snr;		//SNR
    // // @SerializedName("R")
    int rssi;	//RSSI
    // // @SerializedName("D")
    int dBm;		//Rx dBm
} fm_info_t;

typedef union
{
    struct
    {
        uint32_t spk_open : 1;
        uint32_t spk_short : 1;
        uint32_t pwr_lost : 1;
        uint32_t sim_err : 1;
        uint32_t vol_err : 1;
        uint32_t reserve : 27;
    } name;
    uint32_t err;
} __attribute__((packed)) sys_error_code_t;

typedef struct 
{
   // // @SerializedName("Sn")
   char *serial;
   // // @SerializedName("Type")
   uint8_t role;                   //Loại bộ thu (0)/phát (1)
   // // @SerializedName("Ip")
   char ip[48];                  //IP của node
//    // // @SerializedName("Id")
//    public String nodeId;              //deviceId
//    // // @SerializedName("Name")
//    public String nodeName;            //deviceName
    //Trạng thái join room meeting
   // // @SerializedName("Stmt")
   char streaming_master[128];     //Imei của master đang stream, ko stream thì empty
   // // @SerializedName("Stlk")
   char streaming_link[156];       //Link đang streaming, nếu đang ko stream thì empty
   // // @SerializedName("Stst")
   uint8_t stream_state;            //Trạng thái streaming
   // // @SerializedName("Mic")
   bool mic_on;            //Trạng thái Mic On/Off
   // // @SerializedName("Spk")
   bool spk_on;            //Trạng thái Loa meeting On/Off
   // // @SerializedName("Vl2")
   uint8_t vol_music;               // m lượng loa phát nhạc (%)
//    // // @SerializedName("Ver")
    char app_version[16];          //Phiên bản app
//    // // @SerializedName("Hw")
//    char hardware_version[12];               //Phiên bản phần cứng

    // // @SerializedName("A")
    uint8_t temp_air;             //air temperature (oC, < 0 là không xác định)
    // // @SerializedName("N")
    char network[136];	     //Thông tin mạng đang sử dụng
    // // @SerializedName("P")
    uint32_t play_time_of_day;       //Tổng thời lượng phát trong ngày (giây)
    // // @SerializedName("O")
    uint8_t operating_mode;       //Chế độ hoạt động
    // // @SerializedName("L")
    char gps_lat[12];       //Thông tin location (nullable)
    char gps_long[12];
    // // @SerializedName("F")
    fm_info_t fm_info;       //Thông tin FM (nullable)
    // // @SerializedName("M")
    mcu_info_t mcu_info;       //Thông tin từ MCU
    // // @SerializedName("S")
    speaker_info_t speaker;       //Thông tin speaker
    // // @SerializedName("Mp")
    uint8_t mic_plug_state;       //Trạng thái cắm Micro: 1 - Cắm, 0 - Không cắm
    char device_name[128];
    char sim[128];
    sys_error_code_t sys_err;
    uint8_t is_mute;
} ping_message_t;

// MQTT state machine
static ip_mqtt_state_t m_mqtt_state = IP_MQTT_STATE_INIT;
static void set_mqtt_monitor_timeout(unsigned long timeout);
static pthread_mutex_t m_mutex_mqtt;
static int m_auto_disconnect_mqtt = 0;
static ring_buf_t m_ring_buf;
static ring_buf_data_t m_ring_holder[12];
static bool m_send_config_to_svr = true;
static bool m_send_reset_to_svr = true;
static int m_delay_wait_sim_imei = 30;
static MQTTAsync_connectOptions conn_opts = MQTTAsync_connectOptions_initializer;
static MQTTAsync m_mqtt_client;
static char m_active_interface[32] = "NA";
static bool m_query_get_active_interface = false;
static bool m_mqtt_do_resub = false;
static int mqtt_fsm_cycle = 0;
static int m_send_hb_now = 0;
static int m_delay_reboot = 0;
static unsigned long m_mqtt_disconnect_timeout = DEFAULT_MQTT_TIMEOUT_DO_RESET;      // 1000s
static uint32_t m_start_time = 0;
static ip_mqtt_event_cb_t m_callback = NULL;
static void mqtt_send_configuration_to_server();


static broker_info_t m_try_new_brk;
static bool m_renew_brk = false;

static ping_message_t m_ping_msg;

void ip_mqtt_init(ip_mqtt_event_cb_t callback)
{
    m_callback = callback;
    pthread_mutex_init(&m_mutex_mqtt, NULL);
    m_ring_buf.buff = m_ring_holder;
    m_ring_buf.size = sizeof(m_ring_holder)/sizeof(m_ring_holder[0]);
    m_start_time = utils_sys_get_second();
}


int on_mqtt_data_callback(void *context, char *topicName, int topicLen, MQTTAsync_message *message)
{
    A_LOGV("MQTT : Message arrived, len %d\n", message->payloadlen);
    A_LOGV("Topic: %s\n", topicName);
    A_LOGV("Message: %.*s\n", message->payloadlen, (char*)message->payload);

    set_mqtt_monitor_timeout(DEFAULT_MQTT_TIMEOUT_DO_RESET);
    uint32_t size = ring_buf_get_free(&m_ring_buf);
    if (size)
    {
        char *payload = calloc(message->payloadlen+1, 1);
        assert(payload);

        char *p_topic_name = calloc(strlen(topicName) + 1, 1);
        assert(p_topic_name);

        memcpy(p_topic_name, topicName, strlen(topicName));
        memcpy(payload, (char*)message->payload, message->payloadlen);
        // payload[message->payloadlen] = 0;
        static ring_buf_data_t msg;

        msg.len = message->payloadlen;
        msg.data = payload;
        msg.topic = p_topic_name;
        msg.need_free = 1;
        if (!ring_buf_write(&m_ring_buf, &msg))
        {
            A_LOGW("Write to ringbuf failed\r\n");
            free(payload);
            free(p_topic_name);
        }
        else
        {
            A_LOGV("Push to queue OK\r\n");
        }
    }

    MQTTAsync_freeMessage(&message);
    MQTTAsync_free(topicName);
    return 1;
}


void mqtt_publish_failure_cb(void* context, MQTTAsync_failureData* response)
{
    A_LOGW("MQTT : Message send failed token %d error code %d\n", 
                response->token, response->code);
    ip_mqtt_set_fsm_state(IP_MQTT_STATE_DISCONNECTED);
}

void mqtt_publish_complete_cb(void* context, MQTTAsync_successData* response)
{
    // A_LOGV("MQTT : Message with token value %d delivery confirmed\n", 
    //             response->token);
    set_mqtt_monitor_timeout(DEFAULT_MQTT_TIMEOUT_DO_RESET);
}


void ip_mqtt_set_fsm_state(ip_mqtt_state_t state)
{
    pthread_mutex_lock(&m_mutex_mqtt);
    if (state != m_mqtt_state)
    {
        A_LOGI("Change mqtt state to %d\r\n", state);
        mqtt_fsm_cycle = 0;
        m_mqtt_state = state;
    }
    pthread_mutex_unlock(&m_mutex_mqtt);
}

int ip_mqtt_get_state()
{
    return m_mqtt_state;
}

void on_mqtt_conn_lost(void *context, char *cause)
{
    printf("on connection lost\r\n");
    // MQTTAsync client = (MQTTAsync)context;
    // int rc;

    // A_LOGW("\nMQTT : Connection lost\n");
    // if (cause)
    //     A_LOGI("     cause: %s\n", cause);
    // conn_opts.keepAliveInterval = 20;
    // conn_opts.cleansession = 1;

    ip_mqtt_set_fsm_state(IP_MQTT_STATE_DISCONNECTED);
}


static void set_mqtt_monitor_timeout(unsigned long timeout)
{
    pthread_mutex_lock(&m_mutex_mqtt);
    m_mqtt_disconnect_timeout = timeout;
    pthread_mutex_unlock(&m_mutex_mqtt);
}



void on_mqtt_disconnect_failure_cb(void* context, MQTTAsync_failureData* response)
{
    A_LOGI("MQTT : Disconnect failed, rc %d\n", response->code);
}

void on_mqtt_disconnect_success_cb(void* context, MQTTAsync_successData* response)
{
    A_LOGI("MQTT : Successful disconnection\n");
}

void on_mqtt_subscribed_cb(void* context, MQTTAsync_successData* response)
{
    A_LOGI("MQTT : Subscribe succeeded\n");
    set_mqtt_monitor_timeout(DEFAULT_MQTT_TIMEOUT_DO_RESET);
}

void on_subscribe_failure_cb(void* context, MQTTAsync_failureData* response)
{
    A_LOGW("MQTT : Subscribe failed, rc %d\n", response->code);
}


void on_mqtt_connect_failure_cb(void* context, MQTTAsync_failureData* response)
{
    printf("Failed\r\n");
    // A_LOGW("[%s] : Connect failed, rc %d\n", __FUNCTION__, response->code);
}


void on_mqtt_connected_cb(void* context, MQTTAsync_successData* response)
{
    MQTTAsync client = (MQTTAsync)context;
    A_LOGI("MQTT : successful connection\r\n");

    m_query_get_active_interface = true;
    ip_mqtt_set_fsm_state(IP_MQTT_STATE_CONNECTED);
    set_mqtt_monitor_timeout(DEFAULT_MQTT_TIMEOUT_DO_RESET);
    m_send_hb_now = 1;
}

void mqtt_delivery_complete(void* context, MQTTAsync_token token)
{
    // A_LOGV("mqtt_delivery_complete\r\n");
}

static int pub_msg(char *topic, char *payload, int qos)
{
    int rc = -1;
    MQTTAsync_responseOptions opts = MQTTAsync_responseOptions_initializer;
    MQTTAsync_message pubmsg = MQTTAsync_message_initializer;

    if (m_mqtt_state != IP_MQTT_STATE_CONNECTED)
    {
        return rc;
    }


    if (!topic || !payload || strlen(topic) == 0 || strlen(payload) == 0)
    {
        return rc;
    }

    if (strlen(topic) == 0 || strlen(payload) == 0)
    {
        return rc;
    }

    opts.onSuccess = mqtt_publish_complete_cb;
    opts.onFailure = mqtt_publish_failure_cb;
    opts.context = m_mqtt_client;
    pubmsg.payload = payload;
    pubmsg.payloadlen = strlen(payload);
    pubmsg.qos = qos;
    pubmsg.retained = 0;

    if ((rc = MQTTAsync_sendMessage(m_mqtt_client, topic, &pubmsg, &opts)) 
        != MQTTASYNC_SUCCESS)
    {
        A_LOGW("Failed to start sendMessage, return code %d\n", rc);
    }
    else
    {
        A_LOGI("Pub - > %s:\r\n%s\r\n", topic, payload);
    }
    return rc;
}

static void mqtt_send_configuration_to_server()
{
    // TODO
}

void lp_v2_publish_heartbeat_info(ping_message_t *ping)
{
    int len = 0;
    int msg_id = -1;
    char *body = calloc(2048, 1);
    assert(body);
    int index = 0;
    assert(body);
    char topic[96];



    index += sprintf(body+index, "{\"Id\":10,\"Time\":%u,\"Sender\":\"%s\",\"Message\":",
                    utils_sys_get_second(),
                    ping->serial);

    index += sprintf(body+index, "{\"Type\":%d,\"Ip\":\"%s\",\"Stmt\":\"%s\","
                    "\"Stlk\":\"%s\",\"Stst\":%d,\"Mic\":true,\"Spk\":%s,\"Vl1\":%d,\"Vl2\":%d,"
                     "\"A\":%d,\"T\":%d,\"N\":\"%s\",\"P\":%u,\"O\":%d,\"L\":{\"V\":%s,\"K\":%s},\"Ver\":\"%s\",",
                    ping->role, ping->ip, ping->streaming_master, 
                    ping->streaming_link, ping->stream_state, ping->spk_on ? "true":"false", ping->vol_music,  ping->vol_music,
                    ping->temp_air, ping->temp_air, ping->network, ping->play_time_of_day, ping->operating_mode, ping->gps_lat, ping->gps_long,
                    ping->app_version);

    ping->sys_err.name.spk_open = 0;
    ping->sys_err.name.spk_short = 0;
    index += sprintf(body+index, "\"F\":{\"E\":%u,\"F\":%u,\"S\":%d,\"R\":%d,\"D\":%d},",
                                    ping->sys_err.err,
                                    ping->fm_info.freq, ping->fm_info.snr, 
                                    ping->fm_info.rssi, ping->fm_info.dBm);


    index += sprintf(body+index, "\"F\":{\"E\":%u,\"F\":%u,\"S\":%d,\"R\":%d,\"D\":%d},",
                                    ping->sys_err.err,
                                    ping->fm_info.freq, ping->fm_info.snr, 
                                    ping->fm_info.rssi, ping->fm_info.dBm);

    index += sprintf(body+index, "\"SC\":[%s],", ping->sim);


    index += sprintf(body+index, "\"M\":{\"E\":%u,\"F\":%d,\"H\":%d,\"1\":%u,\"2\":%u,\"3\":%u,\"O\":%u,\"I\":%u},",
                    ping->sys_err.err,
                    ping->mcu_info.firmware_version, ping->mcu_info.hardware_version, 
                    ping->mcu_info.vin, ping->mcu_info.v5v, ping->mcu_info.vgsm, 
                    ping->mcu_info.output_control, ping->mcu_info.input_state);

    index += sprintf(body+index, "\"S\":{\"C\":%d,\"D\":%d,\"E\":%u,\"PA\":%d,\"Mute\":%d},\"Name\":\"%s\",\"IsV1\":true}}",
            ping->speaker.audio_class, ping->speaker.detect_value, 
            ping->speaker.err_state,
            ip_io_is_pa_on() ? 1 : 0,
            audio_is_mute() ? 1 : 0,
            ping->device_name);

    // index += sprintf(body+index, "\"Mp\":%u}}", ping->mic_plug_state);

    A_LOGI("Send heartbeat\r\n");
    int found_gr = 0;
    char *im = ip_flk_get_device_name();

    for (int i = 0; i < APP_FLASH_MAX_GROUP_SUPPORT; i++)
    {
        app_flash_group_info_t *gr = app_flash_get_group_info(i);
        if (gr && strlen(gr->group_id))
        {   
            found_gr++;
            if (strlen(im) >= 12)
            {
                sprintf(topic, "tx/%s/%s", gr->group_id, im);
                pub_msg(topic, body, QOS);
            }
        }
    }


    if (found_gr == 0 && strlen(im) >= 12)
    {
        sprintf(topic, "tx/gid/%s", im);
        pub_msg(topic, body, QOS);
    }

    free(body);
}


void ip_mqtt_reply_cfg(char *msg_id, bool is_success, char *msg)
{
    // TODO
    return;
}


void ip_mqtt_heartbeat()
{
    const char *gps_lat = "0.000";
    const char * gps_long = "0.000";

    strcpy(m_ping_msg.device_name, app_flash_get_human_device_name());
    m_ping_msg.mic_on = 0;
    m_ping_msg.mic_plug_state = m_ping_msg.mic_on;
    m_ping_msg.speaker.audio_class = 0;
    m_ping_msg.speaker.detect_value = 0;
    m_ping_msg.speaker.err_state = 0;
    sprintf(m_ping_msg.gps_lat, "%s", "0.000");
    sprintf(m_ping_msg.gps_long, "%s", "0.000");
    m_ping_msg.operating_mode = ip_flk_get_working_mode();
    m_ping_msg.play_time_of_day = audio_get_stream_time_in_day();
    m_ping_msg.fm_info.dBm = 0;
    m_ping_msg.fm_info.snr = 0;
    m_ping_msg.fm_info.snr = 0;
    m_ping_msg.fm_info.freq = 0;
    m_ping_msg.is_mute = audio_is_mute() ?  1 : 0;


    char *ssid = NULL;
    int wifi_rssi = 0;
    int net_idx = 0;
    char nwk_str[128];
    memset(nwk_str, 0, sizeof(nwk_str));

    char *oper = gsm_get_operator();
    if (strlen(oper) > 5)
    {
        net_idx += sprintf(nwk_str+net_idx, "%s,4G,%d,",
                gsm_get_operator(), gsm_get_csq());
    }

    if (wifi_get_name_and_rssi(&ssid, &wifi_rssi))
    {
        net_idx += sprintf(nwk_str+net_idx, "WIFI,%d,",
            wifi_rssi);
    }

    char *eth_ip = eth_get_ip();

    if (strlen(eth_ip))
    {
        net_idx += sprintf(nwk_str+net_idx, "%s", "ETH,");
    }
    
    if (net_idx)
    {
        net_idx--;
    }
    memcpy(m_ping_msg.network, nwk_str, net_idx);
    m_ping_msg.network[net_idx] = 0;

    net_idx = 0;
    char *sim = gsm_get_sim_ccid();
    if (strlen(sim))
    {
        sprintf(m_ping_msg.sim, "{\"S\":%s,\"I\":1}", sim);
    }
    else
    {
        m_ping_msg.sim[0] = 0;
    }


    int temp_air = ip_io_get_temp();
    if (temp_air == 0 || temp_air > 100)
    {
        temp_air = utils_get_cpu_temperature();
    }
    m_ping_msg.temp_air = temp_air;
    sprintf(m_ping_msg.app_version, "%s-%s", FIRMWARE_VERSION, "TTN");
    m_ping_msg.vol_music = ip_flk_get_volume(0);
    m_ping_msg.spk_on = 0;
    m_ping_msg.stream_state = audio_get_rx_stream_state();

    sprintf(m_ping_msg.streaming_link, "%s", ip_audio_get_last_rx_stream_url());
    
    int tmp = 0;
    int ip_len = 0;
    char *int_ip = eth_get_ip();
    if (strlen(eth_ip) > 5)
    {
        ip_len += sprintf(m_ping_msg.ip+ip_len, "e[%s],", int_ip);
    }

    int_ip = wifi_get_ip();
    if (strlen(int_ip) > 5)
    {
        ip_len += sprintf(m_ping_msg.ip+ip_len, "w[%s],", int_ip);
    }

    if (ip_len > 0)
    {
        m_ping_msg.ip[ip_len-1] = 0;
    }

    m_ping_msg.role = 0;        // 0 = slave, 1 = master
    m_ping_msg.serial = ip_flk_get_mac_string();

    m_ping_msg.mcu_info.firmware_version = 0;
    m_ping_msg.mcu_info.hardware_version = 0;
    m_ping_msg.mcu_info.vin = 12000;

    m_ping_msg.mcu_info.vgsm = 0;
    m_ping_msg.mcu_info.v5v = 5000;
    m_ping_msg.mcu_info.input_state = 0;
    uint8_t output = 0;
    m_ping_msg.mcu_info.output_control = output;



    // char *master = app_flash_get_master(app_flash_get_current_streaming_master_index());
    sprintf(m_ping_msg.streaming_master, "%s", ""); 
    lp_v2_publish_heartbeat_info(&m_ping_msg);
}


void ip_mqtt_heartbeat_soon(int delay_s)
{
    if (m_mqtt_state != IP_MQTT_STATE_CONNECTED)
    {
        return;
    }
    if (delay_s > MQTT_AUTO_PUB_INTERVAL)
    {
        delay_s = MQTT_AUTO_PUB_INTERVAL;
    }
    mqtt_fsm_cycle = MQTT_AUTO_PUB_INTERVAL - delay_s;
}


void ip_mqtt_dbg(const char *format, ...)
{
    int payload_len = 0;
    char topic[96];
    char *body;
    int rc;
    int type;
    if (m_mqtt_state != IP_MQTT_STATE_CONNECTED)
    {
        return;
    }


    body = calloc(4096, 1);
    assert(body);

    char time_debug[32];
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(time_debug, "%02d:%02d:%02d", tm.tm_hour, tm.tm_min, tm.tm_sec);

    payload_len += sprintf(body+payload_len, "{\"T\":\"%s\",\"C\":\"", time_debug);
    va_list arg_ptr;

    sprintf(topic, "tx/%s/info", ip_flk_get_mac_string());

    va_start(arg_ptr, format);
    int tmp_len = vsnprintf(body+payload_len, 4096-payload_len, format, arg_ptr);
    va_end(arg_ptr);
    
    payload_len += tmp_len;
    payload_len += sprintf(body+payload_len, "%s", "\"}");

    pub_msg(topic, body, QOS);
    free(body);
}


int ip_mqtt_send_raw(char *topic, char *payload)
{
    if (m_mqtt_state != IP_MQTT_STATE_CONNECTED)
    {
        return -1;
    }

    if (!topic || !payload)
    {
        return -1;
    }
    return pub_msg(topic, payload, QOS);
}

static void mqtt_send_reset_msg()
{
    // TOdO
}

void ip_mqtt_try_new_broker(void *brk)
{
    broker_info_t *new_brk = (broker_info_t*)brk;
    memcpy(&m_try_new_brk, new_brk, sizeof(broker_info_t));
    A_LOGI("NEW %s:%d, %s, %s\r\n", new_brk->url, new_brk->port, new_brk->username, new_brk->password);
    m_renew_brk = true;
    m_mqtt_state = IP_MQTT_STATE_DISCONNECTED;
}

void ip_mqtt_resub_all_master()
{
    m_mqtt_do_resub = true;
}

void* ip_mqtt_thread(void* arg)
{
    int rc;
	static MQTTAsync_disconnectOptions disc_opts = MQTTAsync_disconnectOptions_initializer;
    static int sub_seq = 0;
    static uint32_t m_last_timesend_heartbeat = 0;

    printf("Start MQTT\r\n");
    while (1)
    {
        bool do_restart_interface = false;
        bool do_reboot = false;

        // Ensure thread safe
        pthread_mutex_lock(&m_mutex_mqtt);

        if (m_mqtt_disconnect_timeout == (MQTT_THREAD_CYCLE_MS/2))
        { 
            do_restart_interface = true;
        }
        if (m_mqtt_disconnect_timeout == 0)
        {
            do_reboot = true;
        }
        
        pthread_mutex_unlock(&m_mutex_mqtt);

        if (do_reboot)
        {
            utils_reboot();
        }

        if (do_restart_interface)
        {
            A_LOGW("Auto reset interface\r\n");
            // utils_run_shell_cmd(NULL, 0, true, "timeout 2 service network restart");
            
        }

        if (m_delay_reboot > 0)
        {
            m_delay_reboot--;
            audio_codec_mute(1);
            
            if (m_delay_reboot == 2)
            {
                utils_reboot();
            }

            if (m_delay_reboot == 0)
            {
                exit(0);
            }
        }

        switch (m_mqtt_state)
        {
        case IP_MQTT_STATE_INIT:
        {
            static char m_cli_id[48];
            sprintf(m_cli_id, "PI_%s", ip_flk_get_mac_string());
            sub_seq = 0;
            static char brk[128];
            memset(brk, 0, 128);

            if (!m_renew_brk)
            {
                char *broker = ip_flk_mqtt_get_url();
                conn_opts.username = ip_flk_mqtt_get_username();
                conn_opts.password = ip_flk_mqtt_get_pwd();

                board_hw_sleep(1000);
                if (utils_is_domain_name(broker))
                {
                    // printf("Resolve domain %s\r\n", broker);
                    utils_run_shell_cmd(brk, 128, true, "timeout 3 host %s | awk '/has address/ {print $4}'", broker);
                    char *p = strstr(brk, "\n");
                    if (p)
                    {
                        *p = 0;
                    }
                    // printf("Resolved %s\r\n", brk);
                }
                else
                {
                    sprintf(brk, "%s", broker);
                }

                if (strlen(brk) < 5)
                {
                    continue;
                }
                int index = strlen(brk);
                sprintf(brk+index, ":%d", ip_flk_mqtt_get_port());
                A_LOGV("Broker %s, user %s, pass %s\r\n", brk, conn_opts.username, conn_opts.password);
            }
            else
            {
                A_LOGI("Resolve %s\r\n", m_try_new_brk.url);
                board_hw_sleep(1000);
                if (utils_is_domain_name(m_try_new_brk.url))
                {
                    printf("Resolve domain %s\r\n", m_try_new_brk.url);
                    utils_run_shell_cmd(brk, 128, true, "timeout 3 host %s | awk '/has address/ {print $4}'", m_try_new_brk.url);
                    char *p = strstr(brk, "\n");
                    if (p)
                    {
                        *p = 0;
                    }
                }
                else
                {
                    sprintf(brk, "%s", m_try_new_brk.url);
                }

                if (strlen(brk) < 5)
                {
                    continue;
                }
                int index = strlen(brk);
                sprintf(brk+index, ":%d", m_try_new_brk.port);

                conn_opts.username = m_try_new_brk.username;
                conn_opts.password = m_try_new_brk.password;
                A_LOGV("Broker %s, user %s, pass %s\r\n", brk, conn_opts.username, conn_opts.password);
            }
            if ((rc = MQTTAsync_create(&m_mqtt_client, 
                                        brk, 
                                        m_cli_id, 
                                        MQTTCLIENT_PERSISTENCE_NONE, NULL))
                != MQTTASYNC_SUCCESS)
            {
                A_LOGW("Failed to create client, return code %d\n", rc);
                break;
            }

            if ((rc = MQTTAsync_setCallbacks(m_mqtt_client, 
                                            NULL, 
                                            on_mqtt_conn_lost, 
                                            on_mqtt_data_callback, 
                                            mqtt_delivery_complete)) 
                != MQTTASYNC_SUCCESS)
            {
                A_LOGW("Failed to set callbacks, return code %d\n", rc);
                m_mqtt_state = IP_MQTT_STATE_NEED_DESTROY;
                break;
            }

            conn_opts.keepAliveInterval = 20;
            conn_opts.cleansession = 1;
            conn_opts.onSuccess = on_mqtt_connected_cb;
            conn_opts.onFailure = on_mqtt_connect_failure_cb;
            conn_opts.context = m_mqtt_client;

            mqtt_fsm_cycle = 0;
            m_mqtt_state = IP_MQTT_STATE_CONNECTING;
        }
            break;
        
        case IP_MQTT_STATE_CONNECTING:
            printf("Connecting\r\n");
            m_send_config_to_svr = true;
            if (mqtt_fsm_cycle % 40 == 0)
            {
                if ((rc = MQTTAsync_connect(m_mqtt_client, &conn_opts)) != MQTTASYNC_SUCCESS)
                {
                    A_LOGW("Failed to start connect, return code %d\n", rc);
                    m_mqtt_state = IP_MQTT_STATE_NEED_DESTROY;
                }
                printf("OK\r\n");
                // board_hw_sleep(20000);
            }
            mqtt_fsm_cycle++;
            m_send_hb_now = 1;
            m_mqtt_do_resub = true;
            break;
        
        case IP_MQTT_STATE_CONNECTED:
            if (m_query_get_active_interface)
            {
                m_query_get_active_interface = false;
                utils_get_active_interface(m_active_interface);
            }
            
            if (m_renew_brk)
            {
                ip_flk_save_mqtt_info(&m_try_new_brk);
                m_renew_brk = false;
                memset(&m_try_new_brk, 0, sizeof(m_try_new_brk));
                ip_mqtt_dbg("Save new mqtt OK");
                A_LOGI("Save new cfg\r\n");
            }

            uint32_t now = utils_sys_get_second();
            if (now - m_last_timesend_heartbeat >= 60)
            {
                m_last_timesend_heartbeat = now;
                m_send_hb_now = 1;
            }

            if (mqtt_fsm_cycle % MQTT_AUTO_SUB_INTERVAL == 0 || m_mqtt_do_resub)
            {
                m_mqtt_do_resub = false;
                sub_seq = 0;
                static char topic[10][64];
                static int qos_list[10];
                int j = 0;
                static char* multi_topics[64];
       
                memset(topic, 0, sizeof(topic));
                sprintf(topic[0], "rx/%s", ip_flk_get_mac_string());
                j = 1;
                for (int gr = 0; gr < APP_FLASH_MAX_GROUP_SUPPORT; gr++) 
                {
                    app_flash_group_info_t *tmp_inf = app_flash_get_group_info(gr);
                    if (tmp_inf && tmp_inf->group_id && strlen(tmp_inf->group_id))
                    {
                        A_LOGI("Group raw %s\r\n", tmp_inf->group_id);
                        sprintf(topic[j], "tx/%s", tmp_inf->group_id);
                        A_LOGI("Group[%d] : %s\r\n", j, topic[j]);
                        qos_list[j] = 1;
                        j++;
                    }
                }

                int count = 0;
                for (int i = 0 ; i < 10; i++)
                {
                    if (strlen(topic[i]))
                    {
                        multi_topics[count] = topic[i];
                        qos_list[count] = 1;
                        count++;
                    }
                }

                for (int k = 0; k < 10; k++)
                {
                    if (multi_topics[k] && strlen(multi_topics[k]) > 5)
                    {
                        A_LOGI("Topic[%d] = %s\r\n", k, multi_topics[k]);
                    }
                }
                A_LOGI("Nb of topic %d\r\n", count);

                MQTTAsync_responseOptions opts = MQTTAsync_responseOptions_initializer;
                opts.onSuccess = on_mqtt_subscribed_cb;
                opts.onFailure = on_subscribe_failure_cb;
                opts.context = m_mqtt_client;
                if ((rc = MQTTAsync_subscribeMany(m_mqtt_client, count, multi_topics, qos_list, &opts)) 
                    != MQTTASYNC_SUCCESS)
                {
                    A_LOGW("Failed to start subscribe, return code %d\n", rc);
                    board_hw_sleep(1000);
                }
            }

            if (m_send_hb_now > 0)
            {
                m_send_hb_now = 0;
                ip_mqtt_heartbeat();
            }
            else if (m_send_reset_to_svr)
            {
                m_send_reset_to_svr = false;
                mqtt_send_reset_msg();
                board_hw_sleep(500);
            }
            else if (m_send_config_to_svr && m_delay_wait_sim_imei <= 0)
            {
                m_send_config_to_svr = false;
                mqtt_send_configuration_to_server();
                board_hw_sleep(500);
            }

            if (mqtt_fsm_cycle % AUTO_REPORT_LOAD_AVG == 0)
            {
                char *cpu_load = utils_cpu_get_load_avg();
                char *free_ram = utils_get_free_ram();
                A_LOGI("Free ram: %s\r\n", free_ram);
                char *disk = utils_get_disk_usage();
                if (cpu_load && free_ram && disk)
                {
                    char *endline = strstr(cpu_load, "\n");
                    if (endline) *endline = 0;
                    ip_mqtt_dbg("RAM=%s,CPU=%s,DISK=%s", 
                                free_ram,
                                cpu_load,
                                disk);
                }
            }

            mqtt_fsm_cycle++;
            if (m_auto_disconnect_mqtt > 0)
            {
                m_auto_disconnect_mqtt--;
                if (m_auto_disconnect_mqtt == 0)
                {
                    m_mqtt_state = IP_MQTT_STATE_DISCONNECTED;
                }
            }
            break;
        case IP_MQTT_STATE_DISCONNECTED:
        {
            A_LOGI("MQTT disconnected\r\n");
            MQTTAsync_disconnectOptions opts = MQTTAsync_disconnectOptions_initializer;
            int rc;
            opts.onSuccess = on_mqtt_disconnect_success_cb;
            opts.onFailure = on_mqtt_disconnect_failure_cb;
            if ((rc = MQTTAsync_disconnect(m_mqtt_client, &opts)) != MQTTASYNC_SUCCESS)
            {
                A_LOGW("Failed to start disconnect, return code %d\n", rc);
            }
            board_hw_sleep(2000);
            ip_mqtt_set_fsm_state(IP_MQTT_STATE_NEED_DESTROY);
        }
            break;

        case IP_MQTT_STATE_NEED_DESTROY:
            A_LOGI("Destroying connection\r\n");
            MQTTAsync_destroy(&m_mqtt_client);
            m_mqtt_state = IP_MQTT_STATE_INIT;
            break;

        default:
            break;
        }

        if (ring_buf_get_size_to_read(&m_ring_buf))
        {
            static ring_buf_data_t msg;
            ring_buf_read(&m_ring_buf, &msg);

            if (m_callback) m_callback(msg.topic, msg.data);
            if (msg.need_free)
            {
                if (msg.data) free(msg.data);
                if (msg.topic) free(msg.topic);
            }
        }

        if (m_delay_wait_sim_imei > 0)
        {
            m_delay_wait_sim_imei--;
            if (strlen(gsm_get_sim_ccid()) >= 10)
            {
                m_delay_wait_sim_imei = 0;
            }
        }

        audio_timeout_1s_poll();
        ip_wdt_feed(WDT_THREAD_MQTT);
        board_hw_sleep(MQTT_THREAD_CYCLE_MS);
    }
    A_LOGW("Exit mqtt thread\r\n");
    // exit the current thread
    pthread_exit(NULL);
}