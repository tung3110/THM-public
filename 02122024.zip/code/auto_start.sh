#!/bin/sh
while true
do
  ./amz
  sleep 30
done
