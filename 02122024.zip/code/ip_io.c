#include "ip_io.h"
#include "ip_flk.h"
#include "utils.h"
#include <sys/select.h>
#include <sys/ioctl.h>
#include "app_serial.h"
#include "host_data_layer.h"
#include "ip_dbg.h"
#include <errno.h>  
#include "ip_mqtt.h"
#include "min.h"
#include "min_id.h"
#include "string.h"
#include "ip_wdt.h"
#include "pthread.h"
#include "audio.h"
#include "board_hw.h"

#define MIN_OVER_SOCKET 0
#define MIN_OVER_CDC 1

#define RELAY_SIGNAL 0
#define RELAY_POWER 1


typedef struct
{   
    uint8_t stream_state;
    uint32_t total_streaming_in_second;
    uint32_t total_streaming_in_bytes;
} __attribute__((packed)) rx_ping_msg_t;


static char CDC_PORT_NAME[64] = "/dev/ttyACM";
static int m_cdc_fd = -1;
static volatile int m_delay_turn_off_relay[2] = {0, 0};
static volatile int m_relay_signal_delay_on_timeout = 0;
static ip_io_mcu_io_t m_mcu_io;
static dtmf_info_t m_dtmf_info;

#if MIN_OVER_SOCKET
// Min protocol in socket
static uint32_t m_min_sock_rx_buffer[(MIN_MAX_PAYLOAD+3)/4];
static uint8_t m_sock_dma_payload[1024];
static min_context_t m_min_sock_ctx;
static min_frame_cfg_t m_min_socket_setting = MIN_DEFAULT_CONFIG();
static void on_sock_frame_callback(void *ctx, min_msg_t *frame);
static tcp_state_t m_ipc_tcp_state = TCP_STATE_INIT;
static int m_tcp_sock_fd = -1; 
static rx_ping_msg_t m_last_python_ping_msg;
pthread_mutex_t m_mutex_python;
#endif // MIN_OVER_SOCKET

#if MIN_OVER_CDC
static uint32_t m_min_cdc_rx_buffer[(MIN_MAX_PAYLOAD+3)/4];
static uint8_t m_cdc_dma_payload[1024];
static min_context_t m_min_cdc_ctx;
static min_frame_cfg_t m_min_cdc_setting = MIN_DEFAULT_CONFIG();
static void on_cdc_frame_callback(void *ctx, min_msg_t *frame);
static host_data_layer_ping_msg_t m_last_cdc_msg;
pthread_mutex_t m_mutex_cdc;
host_data_layer_output_t m_gpio_output;
#endif



#if MIN_OVER_CDC

static void send_cdc_data(void *ctx, uint8_t *data, uint8_t len)
{
    if (m_cdc_fd != -1)
    {
        int num_written = app_serial_write(m_cdc_fd, data, len);
        if (num_written == -1) 
        {
            A_LOGI("Send cdc err %d\r\n", errno);
            app_serial_close(m_cdc_fd);
            m_cdc_fd = -1;
        }
        else
        {
            // A_LOGI("Send cdc OK\r\n");
        }
    }
    else
    {
        A_LOGV("Open %s failed\r\n", CDC_PORT_NAME);
    }
}

void min_cdc_signal_cb(void *ctx, min_tx_signal_t signal)
{
    min_context_t *min = ctx;

    switch (signal)
    {
    case MIN_TX_BEGIN:
        break;
    case MIN_TX_FULL:
    {
        send_cdc_data(ctx, 
                    min->tx_frame_payload_buf, 
                    min->tx_frame_bytes_count);
    }
        break;
    case MIN_TX_END:
    {
        send_cdc_data(ctx, 
                    min->tx_frame_payload_buf,
                    min->tx_frame_bytes_count);
    }
        break;
    default:
        break;
    }
}

int ip_io_get_temp()
{
    int value = 0;
    pthread_mutex_lock(&m_mutex_cdc);
    value = m_last_cdc_msg.temperature;
    pthread_mutex_unlock(&m_mutex_cdc);
    return value;
}


static void on_cdc_frame_callback(void *ctx, min_msg_t *frame)
{
    // // printf("Received min frame id %d, total packet received %d\r\n", frame->id, m_total_frame_received);
    // A_LOGI("Min rx [%u] bytes, id %d\r\n", 
    //             frame->len, frame->id);
    switch (frame->id)
    {
    case MIN_ID_PING_MCU:
        {
            host_data_layer_ping_msg_t *msg = (host_data_layer_ping_msg_t*)frame->payload;
            pthread_mutex_lock(&m_mutex_cdc);
            memcpy(&m_last_cdc_msg, msg, sizeof(host_data_layer_ping_msg_t));
            pthread_mutex_unlock(&m_mutex_cdc);
        }
        break;
    
    default:
        break;
    }
}

#endif // MIN_OVER_CDC


void ip_io_init_hardware()
{
#if MIN_OVER_CDC
    pthread_mutex_init(&m_mutex_cdc, NULL);
#endif

#if MIN_OVER_SOCKET
    m_min_socket_setting.get_ms = utils_sys_get_second;
    m_min_socket_setting.last_rx_time = 0x00;
    m_min_socket_setting.rx_callback = on_sock_frame_callback;
    m_min_socket_setting.invalid_crc_callback = NULL;
    m_min_socket_setting.timeout_callback = NULL;
    m_min_socket_setting.tx_byte = NULL;
    m_min_socket_setting.use_timeout_method = 0;
    m_min_socket_setting.use_dma_frame = true;
    m_min_socket_setting.signal = min_socket_signal_cb;
    m_min_socket_setting.tx_frame = send_socket_data;

    m_min_sock_ctx.callback = &m_min_socket_setting;
    m_min_sock_ctx.rx_frame_payload_buf = (uint8_t*)m_min_sock_rx_buffer;
    m_min_sock_ctx.tx_frame_payload_buf = (uint8_t*)m_sock_dma_payload;
    m_min_sock_ctx.tx_frame_payload_size = sizeof(m_sock_dma_payload);
    min_init_context(&m_min_sock_ctx);
#endif

#if MIN_OVER_CDC
    m_min_cdc_setting.get_ms = utils_sys_get_second;
    m_min_cdc_setting.last_rx_time = 0x00;
    m_min_cdc_setting.rx_callback = on_cdc_frame_callback;
    m_min_cdc_setting.invalid_crc_callback = NULL;
    m_min_cdc_setting.timeout_callback = NULL;
    m_min_cdc_setting.tx_byte = NULL;
    m_min_cdc_setting.use_timeout_method = 0;
    m_min_cdc_setting.use_dma_frame = true;
    m_min_cdc_setting.signal = min_cdc_signal_cb;
    m_min_cdc_setting.tx_frame = send_cdc_data;

    m_min_cdc_ctx.callback = &m_min_cdc_setting;
    m_min_cdc_ctx.rx_frame_payload_buf = (uint8_t*)m_min_cdc_rx_buffer;
    m_min_cdc_ctx.tx_frame_payload_buf = (uint8_t*)m_cdc_dma_payload;
    m_min_cdc_ctx.tx_frame_payload_size = sizeof(m_cdc_dma_payload);
    min_init_context(&m_min_cdc_ctx);
#endif
}

void ip_io_set_if_lan_flag(int flag)
{
    m_gpio_output.name.if_eth = flag ? 1 : 0;
}

void ip_io_set_if_wifi_flag(int flag)
{
    m_gpio_output.name.if_wifi = flag ? 1 : 0;
}

void ip_io_set_if_4g_flag(int flag)
{
    m_gpio_output.name.if_4g = flag ? 1 : 0;
}

void ip_io_set_if_4g_toggle()
{
    m_gpio_output.name.if_4g ^= 1;
}

static void do_ping_mcu(void)
{
    A_LOGV("Ping interface %d,%d,%d\r\n", 
            m_gpio_output.name.if_eth, 
            m_gpio_output.name.if_4g, 
            m_gpio_output.name.if_wifi);

#if MIN_OVER_SOCKET
    static uint32_t seq = 0;
    min_msg_t msg;
    msg.id = MIN_ID_PING;
    msg.payload = &seq;
    msg.len = sizeof(seq);
    min_send_frame(&m_min_sock_ctx, &msg);
#endif

#if MIN_OVER_CDC
    // A_LOGI("Do ping\r\n");
    min_msg_t msg;
    msg.id = MIN_ID_SET_GPIO;
    msg.payload = &m_gpio_output;
    msg.len = sizeof(m_gpio_output);
    min_send_frame(&m_min_cdc_ctx, &msg);
#endif
}


bool ip_io_is_lcd_display()
{
    return true;
}


ip_io_mcu_io_t *ip_io_get_mcu_io_value(void)
{
    return &m_mcu_io;
}

int ip_flk_get_limit_level()
{
    return 100;
}

int ip_io_get_active_volume_button()
{
    // TODO
    return 0;
}

int ip_io_get_remote_btn_level()
{
    return m_mcu_io.bit_name.button;
}

void ip_io_set_btn_group(int group)
{
    m_mcu_io.bit_name.group = group ? 1 : 0;
}

uint8_t ip_io_get_btn_group()
{
    return m_mcu_io.bit_name.group;
}

void ip_io_set_remote_btn_on(uint8_t level)
{
    m_mcu_io.bit_name.button = level;
}

int ip_io_is_remote_btn_on()
{
    if (ip_flk_get_device_type() == IP_FLK_DEVICE_TYPE_ENCODER)
    {
        return ip_io_get_btn_group();
    }
    return m_mcu_io.bit_name.button;
}

static void send_mac(void)
{
#if MIN_OVER_SOCKET
    static uint32_t seq = 0;
    min_msg_t msg;
    msg.id = MIN_ID_MAC;
    msg.payload = &seq;
    msg.len = sizeof(seq);
    min_send_frame(&m_min_sock_ctx, &msg);
#endif

#if MIN_OVER_CDC
    min_msg_t msg;
    msg.id = MIN_ID_MAC;
    msg.payload = ip_flk_get_mac_string();
    msg.len = strlen(ip_flk_get_mac_string()) + 1;
    min_send_frame(&m_min_cdc_ctx, &msg);
#endif
}

bool ip_io_is_pa_on()
{
    return m_gpio_output.name.pa;
}

void *ip_io_thread(void *arg)
{
    static int counter = 0;
    static uint32_t tick1s = 0;
    board_hw_sleep(5000);
    A_LOGE("Ping thread\r\n");
    static uint32_t m_last_time_do_ping = 0;
    // tick1s = utils_sys_get_second();
    while (1)
    {
        int m_send_hb_now = 0;
        uint32_t current_tick = utils_sys_get_second();

        if (audio_is_rx_streaming())
        {
            m_gpio_output.name.pa = 1;
        }
        else
        {
            m_gpio_output.name.pa = 0;
        }

        if (ip_mqtt_get_state() == IP_MQTT_STATE_CONNECTED)
        {
            m_gpio_output.name.meeting_led = 1;
        }
        else
        {
            m_gpio_output.name.meeting_led ^= 1;
        }

        if (counter % 100 == 0)
        {
            ip_wdt_feed(WDT_THREAD_CDC);
        }
        

        if (current_tick - m_last_time_do_ping >= 1)
        {
            m_last_time_do_ping = current_tick;
            counter = 0;
            do_ping_mcu();
            send_mac();
            // A_LOGV("1s = %u\r\n", utils_sys_get_second());
        }

        if (audio_is_rx_streaming())
        {
            if (m_gpio_output.name.relay1 == 0)
            {
                m_relay_signal_delay_on_timeout = ip_flk_get_relay_delay_on();
            }
            m_gpio_output.name.relay1 = 1;
        }

        uint32_t diff = utils_sys_get_second() - tick1s;
        if (diff != 0)
        {
            // TODO
            // A_LOGW("1s...\r\n");
            tick1s = utils_sys_get_second();
            static uint32_t m_last_relay_signal_state = 0;

            if (m_last_relay_signal_state != m_gpio_output.name.relay2)
            {
                m_send_hb_now++;
                m_last_relay_signal_state = m_gpio_output.name.relay2;
                if (m_last_relay_signal_state == 0)
                {
                    m_delay_turn_off_relay[RELAY_POWER] = ip_flk_get_relay_delay_off1();
                    A_LOGW("Turn off relay power after %d\r\n", m_delay_turn_off_relay[RELAY_POWER]);
                }
                else if (m_last_relay_signal_state)
                {
                    m_delay_turn_off_relay[RELAY_POWER] = 0; 
                    A_LOGW("Reset delay turn off relay power\r\n");
                }
            }

            if (m_delay_turn_off_relay[RELAY_POWER] > 0)
            {
                if (diff > 0)
                {
                    m_delay_turn_off_relay[RELAY_POWER] -= diff;   
                } 

                if (m_delay_turn_off_relay[RELAY_POWER] <= 0 && !audio_is_allow_relay_run())
                {
                    m_gpio_output.name.relay1 = 0;
                    A_LOGW("Turn off relay power now\r\n");
                    m_send_hb_now++;
                }            
            }
            

            if (m_delay_turn_off_relay[RELAY_SIGNAL] > 0)
            {
                m_delay_turn_off_relay[RELAY_SIGNAL] -= diff;            
            }

            if (m_relay_signal_delay_on_timeout > 0)
            {
                A_LOGI("Delay on relay 2 %d, allow %d\r\n", m_relay_signal_delay_on_timeout, audio_is_allow_relay_run());
                m_relay_signal_delay_on_timeout -= diff;
                if (m_relay_signal_delay_on_timeout <= 0  && audio_is_allow_relay_run())
                {
                    A_LOGW("Turn on relay 2, delay turn off relay %d\r\n", m_delay_turn_off_relay[RELAY_SIGNAL]);
                    m_gpio_output.name.relay2 = 1;
                    m_send_hb_now++;
                }
            }

            int old_mode = ip_flk_get_working_mode();
            if (old_mode == OPERATION_MODE_NO_OPERATION || (m_delay_turn_off_relay[RELAY_SIGNAL] <= 0 && !audio_is_allow_relay_run()))
            {
                m_gpio_output.name.relay2 = 0;
            }
        }

#ifndef BOARD_HW_NO_MCU
        if (m_cdc_fd == -1)
        {
            static int error_count = 0;
            if (error_count++ % 10  == 0) 
            {
                A_LOGW("Open CDC\r\n");
                utils_run_shell_cmd(CDC_PORT_NAME, sizeof(CDC_PORT_NAME), true, "timeout 3 ls /dev/ttyACM*");
                char *q = strstr(CDC_PORT_NAME, "\n");
                if (q) *q = 0;
            }
            m_cdc_fd = app_serial_open(CDC_PORT_NAME, 115200);
            if (m_cdc_fd == -1 && EIO != errno)
            {
                // perror("Open CDC failed ");
                board_hw_sleep(500);
            }
            else
            {
                A_LOGW("Open CDC ok\r\n");
            }
        }

        if (m_cdc_fd != -1)
        {
            uint8_t tmp[64];
            // A_LOGW("Read serial\r\n");
            int size = app_serial_read(m_cdc_fd, tmp, 64);
            if (size == -1)
            {
                if (errno != EAGAIN)
                {
                    A_LOGW("Read serial port failed %d\r\n", errno);
                    board_hw_sleep(5000);
                    // perror("Err ");
                    app_serial_close(m_cdc_fd);
                    m_cdc_fd = -1;
                }
            }
            if (size > 0)
            {
                // for (int i = 0; i < size; i++)
                // {
                //     putchar(tmp[i]);
                // }
                min_rx_feed(&m_min_cdc_ctx, tmp, size);
                // DEBUG_RAW("Min size: %d\r\n", size);
            }
        }
#endif
        if (m_send_hb_now > 0)
        {
            ip_mqtt_heartbeat_soon(2);
        }
        board_hw_sleep(10);
    }
}




void *ip_io_dtmf_poll(void *arg) 
{
    //TODO
    // 0 = state idle
    // 1 = state toggle DTMF1
    // 2 = state toggle DTMF2
    // 3 = state RDS machine power on, do nothing
    static int last_relay1_stt = 0;
    static int last_relay2_stt = 0;
    static int last_dtmf_1_state = 0;
    static int last_dtmf_2_state = 0;
    m_dtmf_info.dtmf1 = ip_flk_get_dtmf_on();
    m_dtmf_info.dtmf2 = ip_flk_get_dtmf_off();
    m_dtmf_info.count = ip_flk_get_dtmf_count();
    m_gpio_output.name.dtmf1 = !ip_flk_get_dtmf_active_level();
    m_gpio_output.name.dtmf2 = !ip_flk_get_dtmf_active_level();

    while (1)
    {
        switch (m_dtmf_info.state) 
        {
            case 0: 
            {
                // Relay 1 switch state from OFF to ON -> turn on DTMF1
                if (last_relay1_stt == 0 && m_gpio_output.name.relay1) 
                {
                    m_dtmf_info.dtmf1 = ip_flk_get_dtmf_on();
                    m_dtmf_info.state = 3;      // Wait for RDS machine power on
                }

                // Relay 2 switch state from ON to OFF -> turn on DTMF2
                if (last_relay2_stt == 1 && !m_gpio_output.name.relay2) 
                {
                    m_dtmf_info.dtmf2 = ip_flk_get_dtmf_on();
                    m_dtmf_info.state = 2;
                    ip_mqtt_dbg("Turn on DTMF2");
                }

                last_relay1_stt = m_gpio_output.name.relay1 ? 1 : 0;
                last_relay2_stt = m_gpio_output.name.relay2 ? 1 : 0;
                if (m_dtmf_info.state > 0) 
                {
                    m_dtmf_info.count = ip_flk_get_dtmf_count();
                }
            }
            break;

            case 1:
                if (m_dtmf_info.dtmf1 <= 0) 
                {
                    if (m_dtmf_info.count > 0) 
                    {
                        m_dtmf_info.count--;
                        m_dtmf_info.dtmf1 = ip_flk_get_dtmf_on();
                        if (m_gpio_output.name.dtmf1 == !ip_flk_get_dtmf_active_level()) 
                        {
                            // ip_mqtt_dbg("DTMF1 ON");
                        }
                        m_gpio_output.name.dtmf1 = ip_flk_get_dtmf_active_level();
                    } 
                    else 
                    {
                        m_dtmf_info.state = 0;
                        m_gpio_output.name.dtmf1 = !ip_flk_get_dtmf_active_level();
                        // ip_mqtt_dbg("DTMF1 OFF");
                    }
                } 
                else 
                {
                    if (m_dtmf_info.dtmf1 >= (ip_flk_get_dtmf_on()/2)) 
                    {
                        if (m_gpio_output.name.dtmf1 == !ip_flk_get_dtmf_active_level()) 
                        {
                            // ip_mqtt_dbg("DTMF1 OFF");
                        }
                        m_gpio_output.name.dtmf1 = ip_flk_get_dtmf_active_level();
                    } 
                    else 
                    {
                        m_gpio_output.name.dtmf1 = !ip_flk_get_dtmf_active_level();
                    }
                    m_dtmf_info.dtmf1--;
                }
                break;

            case 2:
                if (m_dtmf_info.dtmf2 <= 0) 
                {
                    if (m_dtmf_info.count > 0) 
                    {
                        m_dtmf_info.count--;
                        m_dtmf_info.dtmf2 = ip_flk_get_dtmf_on();
                        m_gpio_output.name.dtmf2 = ip_flk_get_dtmf_active_level();
                        // ip_mqtt_dbg("DTMF2 ON");
                    } 
                    else 
                    {
                        m_dtmf_info.state = 0;
                        m_gpio_output.name.dtmf2 = !ip_flk_get_dtmf_active_level();
                        ip_mqtt_dbg("DTMF2 OFF");
                    }
                } 
                else 
                {
                    if (m_dtmf_info.dtmf2 >= (ip_flk_get_dtmf_on()/2)) 
                    {
                        m_gpio_output.name.dtmf2 = ip_flk_get_dtmf_active_level();
                    } 
                    else 
                    {
                        if (m_gpio_output.name.dtmf2 == ip_flk_get_dtmf_active_level()) 
                        {
                            // ip_mqtt_dbg("DTMF2 OFF");
                        }
                        m_gpio_output.name.dtmf2 = !ip_flk_get_dtmf_active_level();
                    }
                    m_dtmf_info.dtmf2--;
                }
                break;
            case 3:
                if (m_dtmf_info.dtmf1 > 0) 
                {
                    m_dtmf_info.dtmf1--;
                }
                if (m_dtmf_info.dtmf1 <= 0) 
                {
                    // ip_mqtt_dbg("DTMF START %d,%d", ip_flk_get_dtmf_on(), ip_flk_get_dtmf_off());
                    m_dtmf_info.state = 1;
                    m_dtmf_info.dtmf1 = ip_flk_get_dtmf_on();
                    m_gpio_output.name.dtmf1 = ip_flk_get_dtmf_active_level();
                }
                break;
            default:
            break;
        }
        if (m_dtmf_info.state)
        {
            A_LOGV("DTMF %d,%d,%d, ON-OFF-COUNT[%d,%d,%d]\r\n", 
                    m_dtmf_info.dtmf1, 
                    m_dtmf_info.dtmf2, 
                    ip_flk_get_dtmf_on(), 
                    ip_flk_get_dtmf_off(),
                    ip_flk_get_dtmf_count(),
                    m_dtmf_info.state);
            A_LOGV("DTMF RELAY %d,%d\r\n", 
                    m_gpio_output.name.dtmf1,
                    m_gpio_output.name.dtmf2);
        }

        int change = 0;
        if (last_dtmf_1_state != m_gpio_output.name.dtmf1 || last_dtmf_2_state != m_gpio_output.name.dtmf2)
        {
            change++;
        }
        if (change)
        {
            ip_mqtt_dbg("DTMF %d,%d, active %d", 
                                m_gpio_output.name.dtmf1, m_gpio_output.name.dtmf2,
                                ip_flk_get_dtmf_active_level());
        }

        last_dtmf_1_state = m_gpio_output.name.dtmf1;
        last_dtmf_2_state = m_gpio_output.name.dtmf2;
        board_hw_sleep(1000);
    }
}
