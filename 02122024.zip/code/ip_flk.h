#ifndef IP_FLK_H
#define IP_FLK_H

#include <stdbool.h>
#include <stdint.h>

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "ip_flk.h"
#include "cJSON.h"

#include "device_config.h"

#define OPERATION_MODE_NA 0
#define OPERATION_MODE_INTERNET 1
#define OPERATION_MODE_FM 2
#define OPERATION_MODE_MIC 3
#define OPERATION_MODE_NO_OPERATION 4 // todo rename
#define OPERATION_MODE_LINE 5
#define OPERATION_MODE_IDLE 6 

#define IP_FLK_DEVICE_TYPE_DECODER 0
#define IP_FLK_DEVICE_TYPE_ENCODER 1
#define IP_FLK_DEVICE_TYPE_MICRO_IP 2
#define IP_FLK_DEVICE_TYPE_2_IN_1 3

#define IP_FLK_VOLUME_TYPE_INTERNET 0
#define IP_FLK_VOLUME_TYPE_LINE 1
#define IP_FLK_VOLUME_TYPE_MIC 2

#define SYS_CONFIG_RAW_DATA "amz.txt"
#define SYS_CONFIG_BINARY_DATA "amz.bin"


bool ip_flk_get_mac_addr(char *mac_raw, char *mac_str);
static uint8_t *gen_aes_key(uint8_t *mac);
void ip_flk_load_configuration();
void ip_flk_save_current_config(void);
void ip_flk_save_gsm_imei(char *imei);
void ip_flk_save_master();
void ip_flk_save_stream_url();
void ip_flk_save_mqtt_info(broker_info_t *info);
int ip_flk_get_dtmf_on();
void ip_flk_save_dtmf_on(int delay);
int ip_flk_get_dtmf_off();
void ip_flk_save_dtmf_off(int delay);
void ip_flk_save_dtmf_count(int count);
int ip_flk_get_dtmf_count(void);
int ip_flk_get_dtmf1();
int ip_flk_get_dtmf_active_level();
void ip_flk_save_dtmf_active(int active);
void ip_flk_save_tty_flag(int tty_enable);
void ip_flk_save_log_level(int level);
void ip_flk_save_log_to_file_flag(int enable);
void ip_flk_save_working_mode(int mode);
void ip_flk_save_relay_delay_on(int value);
int ip_flk_get_relay_delay_off1();
int ip_flk_get_relay_delay_off2();
void ip_flk_save_relay_delay_off_1(int value);
void ip_flk_save_relay_delay_off_2(int value);
int ip_flk_get_relay_delay_on();
void ip_flk_save_relay_DL_ON(int value);
void ip_flk_save_reset_reason(int reason);
int ip_flk_get_reset_counter();
int ip_flk_get_volume(int index);
char *ip_flk_get_last_streaming_master();
void ip_flk_set_last_streaming_master();

int ip_flk_get_working_mode();
void ip_flk_save_reset_counter(int counter);
void ip_flk_save_sim_ccid(char *ccid);
char *ip_flk_get_binary_path(void);
char *ip_flk_get_mac_string(void);

char *ip_flk_mqtt_get_username();
char *ip_flk_mqtt_get_pwd();
char *ip_flk_mqtt_get_url(void);
int ip_flk_mqtt_get_port(void);
void ip_flk_start();
void ip_flk_temporary_set_log_to_tty(int new_log);
void ip_flk_set_sim_imsi(char *imsi);
void ip_flk_set_sim_ccid(char *ccid);
int ip_flk_get_device_type();
char *ip_flk_get_last_streaming_url();
bool ip_flk_is_mute();
void ip_flk_mute(bool is_mute);
char *ip_flk_get_device_name(void);
void ip_flk_set_volume(int index, int volume);
int ip_flk_get_log_level(void);

void app_flash_set_group_name(char *name, uint8_t priority);
app_flash_group_info_t *app_flash_get_group_info(int index);
int app_flash_find_group_priority(char *master);
void app_flash_remove_group(char *id);

void app_flash_remove_all_group(void);
int ip_flk_get_protocol_priority(void);
char *app_flash_get_human_device_name();
/*
 * @brief   Function set device name
 */
void app_flash_set_human_device_name(char *name);
void sys_save_key_and_string_value_to_json(char *key, char *value);
void ip_flk_set_4g_imei(char *imei);
char *ip_flk_get_4g_imei();

#endif // IP_FLK